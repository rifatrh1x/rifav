import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  // In serverless build environments we don't want to crash at import time.
  // We'll create a dummy pool and rely on runtime checks.
  if (process.env.NODE_ENV === "production") {
    console.warn("DATABASE_URL is not set. Database operations will fail at runtime.");
  } else {
    console.warn("DATABASE_URL is not set. Using a placeholder for local development.");
  }
}

const globalForDb = globalThis as unknown as {
  __rifavPool?: Pool;
};

export const pool =
  globalForDb.__rifavPool ??
  new Pool({
    connectionString: databaseUrl || "postgresql://postgres:postgres@127.0.0.1:5432/app_db",
    ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__rifavPool = pool;
}

export const db = drizzle(pool);
