import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { verifyPassword, createSession } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const { identifier, password } = await req.json();
    if (!identifier || !password) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 });
    }
    const id = identifier.toLowerCase();
    const rows = await db
      .select()
      .from(users)
      .where(or(eq(users.username, id), eq(users.email, id)))
      .limit(1);
    if (!rows.length) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }
    const ok = await verifyPassword(password, rows[0].passwordHash);
    if (!ok) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }
    await createSession(rows[0].id);
    const u = rows[0];
    return NextResponse.json({
      user: {
        id: u.id,
        username: u.username,
        email: u.email,
        displayName: u.displayName,
        bio: u.bio,
        avatarUrl: u.avatarUrl,
      },
    });
  } catch (e) {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
