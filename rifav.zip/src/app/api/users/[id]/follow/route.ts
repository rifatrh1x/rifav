import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { follows } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { and, eq } from "drizzle-orm";

export async function POST(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in to follow" }, { status: 401 });
  const { id } = await ctx.params;
  if (id === me.id) return NextResponse.json({ error: "Cannot follow yourself" }, { status: 400 });
  const existing = await db
    .select()
    .from(follows)
    .where(and(eq(follows.followerId, me.id), eq(follows.followingId, id)))
    .limit(1);
  if (existing.length === 0) {
    await db.insert(follows).values({ followerId: me.id, followingId: id });
  }
  return NextResponse.json({ ok: true, following: true });
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in" }, { status: 401 });
  const { id } = await ctx.params;
  await db.delete(follows).where(and(eq(follows.followerId, me.id), eq(follows.followingId, id)));
  return NextResponse.json({ ok: true, following: false });
}
