import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, posts, follows, likes } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { and, desc, eq, inArray } from "drizzle-orm";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const me = await getCurrentUser();
    const { id } = await ctx.params;
    const [u] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!u) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const userPosts = await db
      .select()
      .from(posts)
      .where(eq(posts.userId, id))
      .orderBy(desc(posts.createdAt))
      .limit(30);
    const postIds = userPosts.map((p) => p.id);
    const likeRows = postIds.length
      ? await db.select().from(likes).where(inArray(likes.postId, postIds))
      : [];
    const lc = new Map<string, number>();
    for (const l of likeRows) lc.set(l.postId, (lc.get(l.postId) || 0) + 1);

    const followers = await db.select().from(follows).where(eq(follows.followingId, id));
    const following = await db.select().from(follows).where(eq(follows.followerId, id));

    let isFollowing = false;
    if (me && me.id !== id) {
      const f = await db
        .select()
        .from(follows)
        .where(and(eq(follows.followerId, me.id), eq(follows.followingId, id)))
        .limit(1);
      isFollowing = f.length > 0;
    }

    return NextResponse.json({
      user: {
        id: u.id,
        username: u.username,
        displayName: u.displayName,
        bio: u.bio,
        avatarUrl: u.avatarUrl,
        followerCount: followers.length,
        followingCount: following.length,
        postCount: userPosts.length,
        isFollowing,
        isMe: me?.id === id,
      },
      posts: userPosts.map((p) => ({
        id: p.id,
        caption: p.caption,
        mediaType: p.mediaType,
        mediaUrl: p.mediaUrl,
        createdAt: p.createdAt,
        likeCount: lc.get(p.id) || 0,
      })),
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
