import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, avatarFor } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function PATCH(req: NextRequest) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const updates: Record<string, string> = {};
  if (typeof body.displayName === "string" && body.displayName.trim().length > 0) {
    const dn = body.displayName.trim().slice(0, 60);
    updates.displayName = dn;
    if (!body.avatarUrl) {
      updates.avatarUrl = avatarFor(dn);
    }
  }
  if (typeof body.bio === "string") {
    updates.bio = body.bio.slice(0, 200);
  }
  const av = body.avatarUrl;
  if (typeof av === "string" && av.length > 0) {
    updates.avatarUrl = av;
  }
  await db.update(users).set(updates).where(eq(users.id, me.id));
  const [u] = await db.select().from(users).where(eq(users.id, me.id)).limit(1);
  return NextResponse.json({
    user: {
      id: u.id,
      username: u.username,
      email: u.email,
      displayName: u.displayName,
      bio: u.bio,
      avatarUrl: u.avatarUrl,
    },
  });
}
