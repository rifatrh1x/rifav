import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, conversationMembers, messages, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { and, desc, eq } from "drizzle-orm";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in" }, { status: 401 });
  try {
    const { id } = await ctx.params;
    const member = await db
      .select()
      .from(conversationMembers)
      .where(and(eq(conversationMembers.conversationId, id), eq(conversationMembers.userId, me.id)))
      .limit(1);
    if (!member.length) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const [conv] = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
    if (!conv) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const memberRows = await db
      .select({ user: users })
      .from(conversationMembers)
      .innerJoin(users, eq(users.id, conversationMembers.userId))
      .where(eq(conversationMembers.conversationId, id));

    const msgRows = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(desc(messages.createdAt))
      .limit(500);
    msgRows.reverse();

    return NextResponse.json({
      conversation: { id: conv.id, name: conv.name, isGroup: conv.isGroup },
      members: memberRows.map((m) => ({
        id: m.user.id,
        username: m.user.username,
        displayName: m.user.displayName,
        avatarUrl: m.user.avatarUrl,
      })),
      messages: msgRows.map((m) => ({
        id: m.id,
        body: m.body,
        createdAt: m.createdAt,
        senderId: m.senderId,
      })),
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in" }, { status: 401 });
  try {
    const { id } = await ctx.params;
    const member = await db
      .select()
      .from(conversationMembers)
      .where(and(eq(conversationMembers.conversationId, id), eq(conversationMembers.userId, me.id)))
      .limit(1);
    if (!member.length) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const body = await req.json();
    const text: string = (body.body || "").toString().slice(0, 2000);
    if (!text.trim()) return NextResponse.json({ error: "Empty message" }, { status: 400 });
    const [m] = await db
      .insert(messages)
      .values({ conversationId: id, senderId: me.id, body: text })
      .returning();
    return NextResponse.json({
      message: { id: m.id, body: m.body, createdAt: m.createdAt, senderId: m.senderId },
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
