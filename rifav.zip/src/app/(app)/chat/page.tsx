"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { cls, timeAgo } from "@/lib/utils";

type Conv = {
  id: string; name: string; isGroup: boolean; displayName: string; avatar: string;
  members: { id: string; displayName: string; username: string; avatarUrl: string }[];
  lastMessage: { body: string; createdAt: string; fromMe: boolean } | null;
};

export default function ChatListPage() {
  const router = useRouter();
  const [conversations, setConversations] = useState<Conv[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [q, setQ] = useState("");
  const [users, setUsers] = useState<{ id: string; displayName: string; username: string; avatarUrl: string; bio: string }[]>([]);
  const [filter, setFilter] = useState("");

  useEffect(() => { router.push("/login"); }, [router]);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/conversations", { cache: "no-store" });
    const data = await res.json();
    setConversations(data.conversations || []);
    setLoading(false);
  }, []);

  const loadUsers = useCallback(async () => {
    const res = await fetch("/api/users", { cache: "no-store" });
    const data = await res.json();
    setUsers(data.users || []);
  }, []);

  useEffect(() => {
    load();
    loadUsers();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [load, loadUsers]);

  const filtered = conversations.filter((c) => c.displayName.toLowerCase().includes(q.toLowerCase()));

  const startOneOnOne = async (otherId: string) => {
    const res = await fetch("/api/conversations", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ memberIds: [otherId], isGroup: false }) });
    const data = await res.json();
    if (data.conversationId) window.location.href = `/chat/${data.conversationId}`;
  };

  const startGroup = async (selected: string[], name: string) => {
    const res = await fetch("/api/conversations", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ memberIds: selected, isGroup: true, name }) });
    const data = await res.json();
    if (data.conversationId) window.location.href = `/chat/${data.conversationId}`;
  };

  return (
    <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm overflow-hidden">
        <header className="flex items-center justify-between px-4 sm:px-5 py-3 border-b border-slate-200">
          <div>
            <h1 className="text-xl font-bold">Messages</h1>
            <p className="text-xs text-slate-500">Catch up with friends and groups</p>
          </div>
          <button onClick={() => setShowNew(true)} className="rounded-2xl bg-slate-900 text-white text-sm font-semibold px-3 py-2 inline-flex items-center gap-1.5">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14" /></svg>
            New
          </button>
        </header>
        <div className="px-4 sm:px-5 py-3 border-b border-slate-200">
          <div className="flex items-center gap-2 rounded-2xl bg-slate-100 px-3 py-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search conversations" className="flex-1 bg-transparent outline-none text-sm" />
          </div>
        </div>
        {loading ? (
          <div className="divide-y divide-slate-200">
            {[0,1,2,3].map((i) => (
              <div key={i} className="flex items-center gap-3 p-4">
                <div className="h-12 w-12 rounded-full rifav-shimmer" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-32 rounded rifav-shimmer" />
                  <div className="h-2.5 w-48 rounded rifav-shimmer" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-10 text-center">
            <div className="mx-auto h-12 w-12 rounded-2xl bg-slate-100 grid place-items-center text-slate-500">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
            </div>
            <h3 className="mt-3 font-semibold">No conversations yet</h3>
            <p className="text-sm text-slate-500 mt-1">Start a new chat to break the ice.</p>
            <button onClick={() => setShowNew(true)} className="mt-4 rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 py-2">New message</button>
          </div>
        ) : (
          <ul className="divide-y divide-slate-200">
            {filtered.map((c) => (
              <li key={c.id}>
                <Link href={`/chat/${c.id}`} className="flex items-center gap-3 p-4 hover:bg-slate-50">
                  {c.isGroup ? (
                    <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 text-white grid place-items-center font-semibold">{c.displayName[0]?.toUpperCase() || "G"}</div>
                  ) : (
                    <img src={c.avatar} alt="" className="h-12 w-12 rounded-full ring-1 ring-slate-200 object-cover" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold truncate">{c.displayName}</span>
                      {c.lastMessage && <span className="text-[11px] text-slate-500 ml-2 shrink-0">{timeAgo(c.lastMessage.createdAt)}</span>}
                    </div>
                    <p className={"text-sm truncate " + (c.lastMessage?.fromMe ? "text-slate-500" : "text-slate-700")}>
                      {c.lastMessage ? (<>{c.lastMessage.fromMe && <span className="text-slate-400">You: </span>}{c.lastMessage.body}</>) : (<span className="text-slate-400">No messages yet — say hi 👋</span>)}
                    </p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>

      {showNew && (
        <NewChatModal
          users={users}
          filter={filter}
          setFilter={setFilter}
          onClose={() => setShowNew(false)}
          onOneOnOne={startOneOnOne}
          onGroup={startGroup}
        />
      )}
    </div>
  );
}

function NewChatModal({ users, filter, setFilter, onClose, onOneOnOne, onGroup }: { users: { id: string; displayName: string; username: string; avatarUrl: string; bio: string }[]; filter: string; setFilter: (s: string) => void; onClose: () => void; onOneOnOne: (id: string) => void; onGroup: (ids: string[], name: string) => void; }) {
  const [selected, setSelected] = useState<string[]>([]);
  const [groupName, setGroupName] = useState("");
  const [tab, setTab] = useState<"people" | "group">("people");
  const list = users.filter((u) => u.displayName.toLowerCase().includes(filter.toLowerCase()) || u.username.toLowerCase().includes(filter.toLowerCase()));
  const toggle = (id: string) => setSelected((arr) => (arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]));

  return (
    <div className="fixed inset-0 z-30 bg-slate-900/50 backdrop-blur-sm flex items-end sm:items-center justify-center" onClick={onClose}>
      <div className="w-full sm:max-w-md bg-white sm:rounded-3xl rounded-t-3xl shadow-2xl max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <header className="flex items-center justify-between px-4 py-3 border-b border-slate-200">
          <h3 className="font-semibold">New conversation</h3>
          <button onClick={onClose} className="rounded-full p-2 hover:bg-slate-100">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
        </header>
        <div className="px-4 pt-3">
          <div className="inline-flex rounded-2xl bg-slate-100 p-1">
            <button onClick={() => setTab("people")} className={cls("px-3 py-1.5 text-sm rounded-xl", tab === "people" ? "bg-white shadow font-semibold" : "text-slate-600")}>1-on-1</button>
            <button onClick={() => setTab("group")} className={cls("px-3 py-1.5 text-sm rounded-xl", tab === "group" ? "bg-white shadow font-semibold" : "text-slate-600")}>Group</button>
          </div>
        </div>
        <div className="px-4 py-3">
          <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Search people" className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
        </div>
        <div className="overflow-y-auto px-2 pb-2 flex-1">
          {list.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-6">No people match.</p>
          ) : list.map((u) => {
            const sel = selected.includes(u.id);
            return (
              <button key={u.id} onClick={() => { if (tab === "people") onOneOnOne(u.id); else toggle(u.id); }} className="w-full text-left flex items-center gap-3 rounded-2xl px-2 py-2 hover:bg-slate-50">
                <img src={u.avatarUrl} alt="" className="h-10 w-10 rounded-full ring-1 ring-slate-200" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold truncate">{u.displayName}</div>
                  <div className="text-xs text-slate-500 truncate">@{u.username}</div>
                </div>
                {tab === "group" && (
                  <span className={cls("h-5 w-5 rounded-md border-2 grid place-items-center", sel ? "bg-indigo-600 border-indigo-600" : "border-slate-300")}>
                    {sel && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>}
                  </span>
                )}
              </button>
            );
          })}
        </div>
        {tab === "group" && (
          <div className="border-t border-slate-200 p-3 flex items-center gap-2">
            <input value={groupName} onChange={(e) => setGroupName(e.target.value)} placeholder="Group name" className="flex-1 rounded-2xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
            <button disabled={selected.length < 2 || !groupName.trim()} onClick={() => onGroup(selected, groupName.trim())} className="rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 py-2 disabled:opacity-50">Create ({selected.length})</button>
          </div>
        )}
      </div>
    </div>
  );
}
