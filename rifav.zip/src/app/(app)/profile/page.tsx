"use client";

import { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/components/AuthContext";
import Link from "next/link";
import { useRouter } from "next/navigation";

type Post = { id: string; mediaUrl: string; mediaType: string; caption: string; createdAt: string; likeCount: number };

export default function MyProfilePage() {
  const { user, updateProfile } = useAuth();
  const router = useRouter();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ displayName: "", bio: "", avatarUrl: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) { router.push("/login"); return; }
  }, [user, router]);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const res = await fetch(`/api/posts?scope=user&userId=${user.id}`, { cache: "no-store" });
    const data = await res.json();
    setPosts(data.posts || []);
    setLoading(false);
  }, [user]);

  useEffect(() => { if (user) load(); }, [load, user]);

  useEffect(() => {
    if (user) setForm({ displayName: user.displayName, bio: user.bio, avatarUrl: user.avatarUrl });
  }, [user]);

  if (!user) return null;

  const onSave = async () => {
    setBusy(true);
    setError(null);
    try {
      await updateProfile({ displayName: form.displayName, bio: form.bio, avatarUrl: form.avatarUrl });
      setEditing(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to update");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm overflow-hidden">
        <div className="h-28 sm:h-36 bg-gradient-to-r from-indigo-500 via-fuchsia-500 to-rose-500" />
        <div className="px-4 sm:px-6 pb-5 -mt-12 sm:-mt-14">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            <img src={user.avatarUrl} alt="" className="h-24 w-24 sm:h-28 sm:w-28 rounded-full ring-4 ring-white object-cover shadow" />
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold tracking-tight truncate">{user.displayName}</h1>
              <p className="text-sm text-slate-500">@{user.username}</p>
              {user.bio && <p className="mt-2 text-sm text-slate-700 whitespace-pre-wrap">{user.bio}</p>}
              <div className="mt-3 flex items-center gap-5 text-sm text-slate-600">
                <span><strong className="text-slate-900">{posts.length}</strong> posts</span>
                <Link href={`/u/${user.username}`} className="hover:underline">View public profile →</Link>
              </div>
            </div>
            <div className="sm:self-start sm:mt-1">
              <button onClick={() => setEditing(true)} className="rounded-2xl border border-slate-200 hover:border-slate-300 text-sm font-semibold px-4 py-2">Edit profile</button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <div className="flex items-center justify-between px-1 mb-3">
          <h2 className="text-sm font-semibold text-slate-700">Posts</h2>
          <Link href="/upload" className="text-sm font-semibold text-indigo-600 hover:underline">+ New post</Link>
        </div>
        {loading ? (
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
            {[0,1,2,3,4,5].map((i) => <div key={i} className="aspect-square rounded-xl rifav-shimmer" />)}
          </div>
        ) : posts.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-slate-300 p-10 text-center bg-white">
            <p className="font-semibold">No posts yet</p>
            <p className="text-sm text-slate-500 mt-1">Share your first moment — it takes a second.</p>
            <Link href="/upload" className="mt-3 inline-block rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 py-2">Create post</Link>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
            {posts.map((p) => (
              <div key={p.id} className="relative aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200 group">
                <img src={p.mediaUrl} alt="" className="w-full h-full object-cover" />
                {p.mediaType === "video" && (
                  <div className="absolute top-1.5 right-1.5 rounded-full bg-black/55 p-1">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {editing && (
        <div className="fixed inset-0 z-30 bg-slate-900/50 backdrop-blur-sm flex items-end sm:items-center justify-center" onClick={() => setEditing(false)}>
          <div className="w-full sm:max-w-md bg-white sm:rounded-3xl rounded-t-3xl shadow-2xl p-5 sm:p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Edit profile</h3>
              <button onClick={() => setEditing(false)} className="rounded-full p-2 hover:bg-slate-100">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Display name</label>
                <input value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} className="w-full rounded-2xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Bio</label>
                <textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} rows={3} maxLength={200} className="w-full rounded-2xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300 resize-none" />
                <div className="text-right text-[10px] text-slate-400">{form.bio.length}/200</div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Avatar URL</label>
                <input value={form.avatarUrl} onChange={(e) => setForm({ ...form, avatarUrl: e.target.value })} placeholder="Paste an image URL or leave as is" className="w-full rounded-2xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
              </div>
              {error && <p className="text-sm text-rose-600">{error}</p>}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button onClick={() => setEditing(false)} className="rounded-2xl px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100">Cancel</button>
                <button onClick={onSave} disabled={busy} className="rounded-2xl bg-slate-900 text-white text-sm font-semibold px-4 py-2 disabled:opacity-50">{busy ? "Saving…" : "Save changes"}</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
