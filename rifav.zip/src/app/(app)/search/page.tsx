"use client";

import { useEffect, useState, useCallback, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { cls, timeAgo } from "@/lib/utils";

type UserHit = { id: string; username: string; displayName: string; bio: string; avatarUrl: string };
type PostHit = { id: string; caption: string; mediaType: string; mediaUrl: string; createdAt: string };

function SearchInner() {
  const params = useSearchParams();
  const router = useRouter();
  const initial = params.get("q") || "";
  const [q, setQ] = useState(initial);
  const [users, setUsers] = useState<UserHit[]>([]);
  const [posts, setPosts] = useState<PostHit[]>([]);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"all" | "people" | "posts">("all");

  const run = useCallback(async (query: string) => {
    if (!query.trim()) { setUsers([]); setPosts([]); return; }
    setLoading(true);
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`, { cache: "no-store" });
    const data = await res.json();
    setUsers(data.users || []);
    setPosts(data.posts || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => {
      run(q);
      if (q) router.replace(`/search?q=${encodeURIComponent(q)}`);
      else router.replace(`/search`);
    }, 250);
    return () => clearTimeout(t);
  }, [q, run, router]);

  const trending = ["photography", "food", "travel", "fitness", "design", "film", "skate", "coffee"];

  return (
    <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm p-4 sm:p-5">
        <h1 className="text-2xl font-bold tracking-tight">Search</h1>
        <p className="text-sm text-slate-500 mt-1">Find people, posts, and ideas across rifav.</p>
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-slate-100 px-3 py-2.5">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search rifav" className="flex-1 bg-transparent outline-none text-sm" />
          {q && <button onClick={() => setQ("")} className="text-xs text-slate-500 hover:underline">clear</button>}
        </div>

        {!q && (
          <div className="mt-6">
            <h2 className="text-sm font-semibold text-slate-700">Try searching for</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {trending.map((t) => (
                <button key={t} onClick={() => setQ(t)} className="rounded-full bg-slate-100 hover:bg-slate-200 text-sm text-slate-700 px-3 py-1.5">#{t}</button>
              ))}
            </div>
          </div>
        )}

        {q && (
          <>
            <div className="mt-5 inline-flex rounded-2xl bg-slate-100 p-1">
              {(["all", "people", "posts"] as const).map((t) => (
                <button key={t} onClick={() => setTab(t)} className={cls("px-3 py-1.5 text-sm rounded-xl capitalize", tab === t ? "bg-white shadow font-semibold" : "text-slate-600")}>
                  {t} {t === "people" ? `(${users.length})` : t === "posts" ? `(${posts.length})` : `(${users.length + posts.length})`}
                </button>
              ))}
            </div>

            {loading && <p className="mt-4 text-sm text-slate-500">Searching…</p>}
            {!loading && users.length === 0 && posts.length === 0 && (
              <div className="mt-6 rounded-2xl bg-slate-50 border border-slate-200 p-8 text-center">
                <p className="font-semibold">No results for "{q}"</p>
                <p className="text-sm text-slate-500 mt-1">Try a different word or check your spelling.</p>
              </div>
            )}

            {(tab === "all" || tab === "people") && users.length > 0 && (
              <section className="mt-5">
                <h2 className="text-sm font-semibold text-slate-700 mb-2">People</h2>
                <ul className="divide-y divide-slate-200">
                  {users.map((u) => (
                    <li key={u.id}>
                      <Link href={`/u/${u.username}`} className="flex items-center gap-3 py-3 hover:bg-slate-50 rounded-xl px-2 -mx-2">
                        <img src={u.avatarUrl} alt="" className="h-11 w-11 rounded-full ring-1 ring-slate-200" />
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold truncate">{u.displayName}</div>
                          <div className="text-xs text-slate-500 truncate">@{u.username}</div>
                          {u.bio && <div className="text-xs text-slate-600 truncate mt-0.5">{u.bio}</div>}
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {(tab === "all" || tab === "posts") && posts.length > 0 && (
              <section className="mt-5">
                <h2 className="text-sm font-semibold text-slate-700 mb-2">Posts</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {posts.map((p) => (
                    <div key={p.id} className="relative aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
                      <img src={p.mediaUrl} alt="" className="w-full h-full object-cover" />
                      {p.mediaType === "video" && (
                        <div className="absolute top-1.5 right-1.5 rounded-full bg-black/55 p-1">
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
                        </div>
                      )}
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-2 text-white text-[11px] line-clamp-2">
                        {p.caption || "—"} <span className="opacity-70">· {timeAgo(p.createdAt)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="p-8 text-slate-500">Loading…</div>}>
      <SearchInner />
    </Suspense>
  );
}
