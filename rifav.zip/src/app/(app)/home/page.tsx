"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PostCard, type PostItem } from "@/components/PostCard";
import { useAuth } from "@/components/AuthContext";
import { cls, timeAgo } from "@/lib/utils";

type Story = { id: string; username: string; displayName: string; avatarUrl: string; hasNew?: boolean };

export default function HomePage() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<PostItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openComments, setOpenComments] = useState<PostItem | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/posts?scope=explore", { cache: "no-store" });
      const data = await res.json();
      setPosts(data.posts || []);
    } catch (e) {
      setError("Failed to load feed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const stories: Story[] = (() => {
    const seen = new Set<string>();
    const list: Story[] = [];
    for (const p of posts) {
      if (seen.has(p.author.id)) continue;
      seen.add(p.author.id);
      list.push({ id: p.author.id, username: p.author.username, displayName: p.author.displayName, avatarUrl: p.author.avatarUrl, hasNew: p.author.id !== user?.id });
      if (list.length >= 12) break;
    }
    return list;
  })();

  return (
    <div className="mx-auto max-w-2xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm px-3 py-3 mb-4">
        <div className="flex gap-3 overflow-x-auto no-scrollbar">
          {stories.length === 0 && !loading && <p className="text-sm text-slate-500 px-2 py-1">No stories yet.</p>}
          {stories.map((s) => (
            <Link key={s.id} href={`/u/${s.username}`} className="flex flex-col items-center gap-1.5 shrink-0">
              <div className={cls("p-[2.5px] rounded-full", s.hasNew ? "bg-gradient-to-tr from-yellow-400 via-rose-500 to-indigo-500" : "bg-slate-200")}>
                <div className="bg-white p-[2px] rounded-full">
                  <img src={s.avatarUrl} alt="" className="h-14 w-14 rounded-full object-cover" />
                </div>
              </div>
              <span className="text-[11px] text-slate-700 max-w-[64px] truncate">{s.username}</span>
            </Link>
          ))}
        </div>
      </div>

      {loading && (
        <div className="space-y-4">
          {[0,1,2].map((i) => (
            <div key={i} className="rounded-3xl bg-white border border-slate-200/70 overflow-hidden">
              <div className="p-4 flex items-center gap-3">
                <div className="h-10 w-10 rounded-full rifav-shimmer" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-32 rounded rifav-shimmer" />
                  <div className="h-2.5 w-20 rounded rifav-shimmer" />
                </div>
              </div>
              <div className="aspect-square w-full rifav-shimmer" />
              <div className="p-4 space-y-2">
                <div className="h-3 w-3/4 rounded rifav-shimmer" />
                <div className="h-3 w-1/2 rounded rifav-shimmer" />
              </div>
            </div>
          ))}
        </div>
      )}

      {error && <div className="rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 text-sm">{error}</div>}

      {!loading && !error && posts.length === 0 && (
        <div className="rounded-3xl bg-white border border-dashed border-slate-300 p-10 text-center">
          <div className="mx-auto h-14 w-14 rounded-2xl bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 grid place-items-center text-white">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
          </div>
          <h3 className="mt-3 text-lg font-semibold">No posts yet</h3>
          <p className="mt-1 text-sm text-slate-500">Be the first to share something amazing.</p>
          {user ? (
            <Link href="/upload" className="mt-4 inline-block rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 py-2">Create post</Link>
          ) : (
            <Link href="/signup" className="mt-4 inline-block rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 py-2">Sign up to post</Link>
          )}
        </div>
      )}

      <div className="space-y-5">
        {posts.map((p) => (
          <PostCard key={p.id} post={p} onChanged={(next) => setPosts((arr) => arr.map((x) => (x.id === next.id ? next : x)))} onOpenComments={(post) => setOpenComments(post)} />
        ))}
      </div>

      {!loading && posts.length > 0 && <p className="text-center text-xs text-slate-400 py-6">You're all caught up ✨</p>}

      {openComments && <CommentsModal post={openComments} onClose={() => setOpenComments(null)} />}
    </div>
  );
}

function CommentsModal({ post, onClose }: { post: PostItem; onClose: () => void }) {
  const [comments, setComments] = useState<{ id: string; body: string; createdAt: string; author: { id: string; username: string; displayName: string; avatarUrl: string } }[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const { user } = useAuth();
  const router = useRouter();

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch(`/api/posts/${post.id}/comments`, { cache: "no-store" });
    const data = await res.json();
    setComments(data.comments || []);
    setLoading(false);
  }, [post.id]);

  useEffect(() => { load(); }, [load]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { router.push("/login"); return; }
    if (!text.trim() || busy) return;
    setBusy(true);
    const t = text;
    setText("");
    try {
      const res = await fetch(`/api/posts/${post.id}/comments`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ body: t }) });
      if (res.ok) {
        const data = await res.json();
        setComments((arr) => [...arr, data.comment]);
      } else {
        setText(t);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-30 bg-slate-900/50 backdrop-blur-sm flex items-end sm:items-center justify-center" onClick={onClose}>
      <div className="w-full sm:max-w-md bg-white sm:rounded-3xl rounded-t-3xl shadow-2xl flex flex-col max-h-[85vh]" onClick={(e) => e.stopPropagation()}>
        <header className="flex items-center justify-between px-4 py-3 border-b border-slate-200">
          <h3 className="font-semibold">Comments</h3>
          <button onClick={onClose} className="rounded-full p-2 hover:bg-slate-100">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
        </header>
        <div className="overflow-y-auto p-4 space-y-3 flex-1">
          {loading && <p className="text-sm text-slate-500">Loading comments…</p>}
          {!loading && comments.length === 0 && <p className="text-sm text-slate-500 text-center py-10">Be the first to comment.</p>}
          {comments.map((c) => (
            <div key={c.id} className="flex gap-2.5">
              <img src={c.author.avatarUrl} alt="" className="h-8 w-8 rounded-full ring-1 ring-slate-200" />
              <div className="flex-1 min-w-0">
                <div className="rounded-2xl bg-slate-100 px-3 py-2">
                  <div className="text-xs font-semibold text-slate-800">{c.author.displayName}</div>
                  <div className="text-sm text-slate-800 break-words whitespace-pre-wrap">{c.body}</div>
                </div>
                <div className="text-[11px] text-slate-500 mt-1 ml-1">{timeAgo(c.createdAt)}</div>
              </div>
            </div>
          ))}
        </div>
        {user ? (
          <form onSubmit={submit} className="border-t border-slate-200 p-3 flex gap-2">
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Add a comment…" className="flex-1 rounded-2xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" />
            <button disabled={busy || !text.trim()} className="rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 disabled:opacity-50">Post</button>
          </form>
        ) : (
          <div className="border-t border-slate-200 p-3 text-center text-sm">
            <Link href="/login" className="font-semibold text-indigo-600 hover:underline">Log in</Link> to add a comment
          </div>
        )}
      </div>
    </div>
  );
}
