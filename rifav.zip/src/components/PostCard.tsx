"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";
import { cls, timeAgo } from "@/lib/utils";

export type PostItem = {
  id: string;
  caption: string;
  mediaType: "image" | "video";
  mediaUrl: string;
  createdAt: string;
  likeCount: number;
  commentCount: number;
  likedByMe: boolean;
  author: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string;
  };
};

export function PostCard({
  post,
  onChanged,
  onOpenComments,
}: {
  post: PostItem;
  onChanged?: (next: PostItem) => void;
  onOpenComments?: (post: PostItem) => void;
}) {
  const [data, setData] = useState<PostItem>(post);
  const [pending, startTransition] = useTransition();
  const [imgLoaded, setImgLoaded] = useState(false);
  const { user } = useAuth();
  const router = useRouter();

  const toggleLike = () => {
    if (!user) {
      router.push("/login");
      return;
    }
    const next: PostItem = {
      ...data,
      likedByMe: !data.likedByMe,
      likeCount: data.likeCount + (data.likedByMe ? -1 : 1),
    };
    setData(next);
    onChanged?.(next);
    startTransition(async () => {
      try {
        const res = await fetch(`/api/posts/${data.id}/like`, {
          method: data.likedByMe ? "DELETE" : "POST",
        });
        if (!res.ok) {
          setData(data);
          onChanged?.(data);
        }
      } catch {
        setData(data);
        onChanged?.(data);
      }
    });
  };

  const isVideo = data.mediaType === "video";

  return (
    <article className="rounded-3xl bg-white shadow-[0_1px_2px_rgba(15,23,42,0.06),0_8px_24px_-12px_rgba(15,23,42,0.12)] border border-slate-200/70 overflow-hidden">
      <header className="flex items-center gap-3 px-4 sm:px-5 pt-4 pb-3">
        <Link href={`/u/${data.author.username}`} className="shrink-0">
          {data.author.avatarUrl ? (
            <img src={data.author.avatarUrl} alt="" className="h-10 w-10 rounded-full ring-1 ring-slate-200 object-cover" />
          ) : (
            <div className="h-10 w-10 rounded-full bg-slate-200" />
          )}
        </Link>
        <div className="min-w-0 flex-1">
          <Link href={`/u/${data.author.username}`} className="block text-sm font-semibold text-slate-900 hover:underline truncate">
            {data.author.displayName}
          </Link>
          <div className="text-xs text-slate-500 truncate">@{data.author.username} · {timeAgo(data.createdAt)}</div>
        </div>
      </header>

      <div className="relative bg-slate-100">
        {!imgLoaded && <div className="aspect-square w-full rifav-shimmer" />}
        <img
          src={data.mediaUrl}
          alt={data.caption || "post"}
          className={cls("w-full max-h-[640px] object-cover bg-slate-100", !imgLoaded && "hidden")}
          onLoad={() => setImgLoaded(true)}
        />
        {isVideo && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="rounded-full bg-black/55 p-4 backdrop-blur-sm">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
            </div>
          </div>
        )}
      </div>

      <div className="px-4 sm:px-5 py-3">
        <div className="flex items-center gap-1 -ml-2">
          <button
            onClick={toggleLike}
            disabled={pending}
            className={cls("p-2 rounded-full hover:bg-slate-100 transition", data.likedByMe && "liked-heart")}
            aria-label="Like"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill={data.likedByMe ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={cls(data.likedByMe ? "text-rose-500" : "text-slate-700")}>
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
            </svg>
          </button>
          <button
            onClick={() => onOpenComments?.(data)}
            className="p-2 rounded-full hover:bg-slate-100 transition"
            aria-label="Comments"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-700">
              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
            </svg>
          </button>
          <div className="flex-1" />
          <span className="text-xs text-slate-500">{data.likeCount} likes · {data.commentCount} comments</span>
        </div>
        {data.caption && (
          <p className="mt-2 text-sm text-slate-800 leading-relaxed">
            <Link href={`/u/${data.author.username}`} className="font-semibold mr-1 hover:underline">
              {data.author.username}
            </Link>
            <span className="whitespace-pre-wrap break-words">{data.caption}</span>
          </p>
        )}
      </div>
    </article>
  );
}
