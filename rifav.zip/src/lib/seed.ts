import { db } from "@/db";
import {
  users,
  posts,
  likes,
  comments,
  follows,
  conversations,
  conversationMembers,
  messages,
} from "@/db/schema";
import { hashPassword, avatarFor } from "@/lib/auth";
import { placeholderImage } from "@/lib/utils";
import { sql } from "drizzle-orm";

const DEMO_PASSWORD = "password123";

const PEOPLE = [
  { username: "rifav", displayName: "Rifav Ahmed", bio: "Building rifav — the home for creators ✨", accent: true },
  { username: "ava.carter", displayName: "Ava Carter", bio: "Photographer · Traveler · Coffee snob ☕📷" },
  { username: "leo.martin", displayName: "Leo Martin", bio: "Indie game dev. Working on something big 🎮" },
  { username: "mira.kapoor", displayName: "Mira Kapoor", bio: "Recipe creator & food stylist. Veg-friendly 🌱" },
  { username: "theo.b", displayName: "Theo Bennett", bio: "Filmmaker. Cinema is my love language 🎬" },
  { username: "sana.q", displayName: "Sana Qureshi", bio: "Designer · Plant mom · Cat lady 🌿🐈" },
  { username: "kenji.t", displayName: "Kenji Tanaka", bio: "Skateboarder & sneaker collector 🛹" },
  { username: "nina.rose", displayName: "Nina Rossi", bio: "Yoga instructor. Find me on the mat 🧘‍♀️" },
];

const CAPTIONS = [
  "Sunset chase in the city tonight 🌇",
  "Finally got the new lens — obsessed.",
  "Cooked this up after a long day. Worth it.",
  "Skating laps at the new park. So smooth.",
  "Studio days hit different when the light's right.",
  "Brunch with the best people. So grateful 🥞",
  "Hiking through the pines. Air up here is unreal.",
  "Late night edits. Coffee #4 fueling the grind.",
  "Throwback to last summer. Wild how fast it flew.",
  "Field trip with the crew. No laptops allowed.",
  "First snow of the season. Cozy mode: ON ❄️",
  "Street art is the best free museum.",
  "New sketchbook, new pages, new possibilities.",
  "Just dropped a new reel — go watch it 🎬",
  "Today I learned something and it broke my brain.",
  "The dogs got a new friend today. Meet Mochi 🐶",
  "Tiny desk setup, big dreams.",
  "Camera roll dump. Pick a favorite.",
  "When the algorithm finally blessed you 😂",
  "I make things. Sometimes they're even good.",
];

const COMMENT_BODIES = [
  "🔥🔥🔥",
  "This is gorgeous!",
  "How did you do that??",
  "Saving this immediately.",
  "Goals, honestly.",
  "The colors 😍",
  "I need to try this.",
  "Where is this??",
  "Stunning work 🙌",
  "Made my whole day.",
  "10/10 would frame.",
  "Drop the recipe please!",
];

const CHAT_THREADS: Array<{
  name: string;
  isGroup: boolean;
  members: string[];
  msgs: Array<{ from: string; body: string }>;
}> = [
  {
    name: "",
    isGroup: false,
    members: ["rifav", "ava.carter"],
    msgs: [
      { from: "ava.carter", body: "Hey! Loved your latest post 💛" },
      { from: "rifav", body: "Thank you so much! Yours too — the rooftop shot was unreal." },
      { from: "ava.carter", body: "Want to collab on a series this weekend?" },
      { from: "rifav", body: "Absolutely. DM me the spot 🤝" },
    ],
  },
  {
    name: "Creator Hangout",
    isGroup: true,
    members: ["rifav", "ava.carter", "leo.martin", "theo.b", "mira.kapoor"],
    msgs: [
      { from: "leo.martin", body: "Game night at my place Friday?" },
      { from: "theo.b", body: "I'm in if we do Mario Kart" },
      { from: "mira.kapoor", body: "Bringing snacks 🍪" },
      { from: "ava.carter", body: "Count me in! What time?" },
      { from: "rifav", body: "8pm works. I'll grab drinks." },
    ],
  },
  {
    name: "",
    isGroup: false,
    members: ["rifav", "mira.kapoor"],
    msgs: [
      { from: "mira.kapoor", body: "Recipe drop incoming 🚨" },
      { from: "rifav", body: "I've been waiting all week lol" },
    ],
  },
  {
    name: "Squad",
    isGroup: true,
    members: ["rifav", "sana.q", "kenji.t", "nina.rose"],
    msgs: [
      { from: "sana.q", body: "Saturday hike — who's down?" },
      { from: "kenji.t", body: "Send the trail link!" },
      { from: "nina.rose", body: "I'll bring the trail mix 🏞️" },
    ],
  },
];

export async function seedIfEmpty() {
  try {
    const result = await db.execute(sql`select count(*)::int as count from users`);
    const count = (result.rows[0] as { count: number })?.count || 0;
    if (count > 0) return;
  } catch {
    return; // tables not ready yet
  }

  const pw = await hashPassword(DEMO_PASSWORD);

  const userRows = await db
    .insert(users)
    .values(
      PEOPLE.map((p) => ({
        username: p.username,
        email: `${p.username}@rifav.app`,
        passwordHash: pw,
        displayName: p.displayName,
        bio: p.bio,
        avatarUrl: avatarFor(p.displayName),
      }))
    )
    .returning();

  const byUsername = new Map(userRows.map((u) => [u.username, u]));

  const allPosts: { id: string; userId: string; idx: number }[] = [];
  let postIdx = 0;
  for (const u of userRows) {
    const numPosts = 2 + (u.username.length % 2);
    for (let i = 0; i < numPosts; i++) {
      const caption = CAPTIONS[(postIdx + i) % CAPTIONS.length];
      const kind = i % 4 === 0 ? "video" : "image";
      const [p] = await db
        .insert(posts)
        .values({
          userId: u.id,
          caption,
          mediaType: kind,
          mediaUrl: placeholderImage(`${u.username}-${i}`, kind as "image" | "video"),
        })
        .returning();
      allPosts.push({ id: p.id, userId: u.id, idx: postIdx + i });
    }
    postIdx += 3;
  }

  const likeRows: { userId: string; postId: string }[] = [];
  for (const u of userRows) {
    const candidates = allPosts.filter((p) => p.userId !== u.id);
    for (let i = 0; i < 3 + (u.username.length % 3); i++) {
      const pick = candidates[(i * 7 + u.username.length) % candidates.length];
      if (!likeRows.some((l) => l.userId === u.id && l.postId === pick.id)) {
        likeRows.push({ userId: u.id, postId: pick.id });
      }
    }
  }
  if (likeRows.length) await db.insert(likes).values(likeRows);

  const commentRows: { postId: string; userId: string; body: string }[] = [];
  let ci = 0;
  for (const p of allPosts.slice(0, 14)) {
    for (let i = 0; i < 2; i++) {
      const author = userRows[(ci + i * 3) % userRows.length];
      if (author.id === p.userId) continue;
      commentRows.push({
        postId: p.id,
        userId: author.id,
        body: COMMENT_BODIES[ci % COMMENT_BODIES.length],
      });
      ci++;
    }
  }
  if (commentRows.length) await db.insert(comments).values(commentRows);

  const followRows: { followerId: string; followingId: string }[] = [];
  const rifav = byUsername.get("rifav")!;
  for (const u of userRows) {
    if (u.id !== rifav.id) {
      followRows.push({ followerId: rifav.id, followingId: u.id });
      followRows.push({ followerId: u.id, followingId: rifav.id });
    }
  }
  followRows.push({ followerId: byUsername.get("ava.carter")!.id, followingId: byUsername.get("theo.b")!.id });
  followRows.push({ followerId: byUsername.get("theo.b")!.id, followingId: byUsername.get("ava.carter")!.id });
  followRows.push({ followerId: byUsername.get("mira.kapoor")!.id, followingId: byUsername.get("sana.q")!.id });
  followRows.push({ followerId: byUsername.get("sana.q")!.id, followingId: byUsername.get("mira.kapoor")!.id });
  followRows.push({ followerId: byUsername.get("leo.martin")!.id, followingId: byUsername.get("kenji.t")!.id });
  if (followRows.length) await db.insert(follows).values(followRows);

  for (const t of CHAT_THREADS) {
    const [c] = await db
      .insert(conversations)
      .values({ isGroup: t.isGroup, name: t.name })
      .returning();
    const members = t.members
      .map((un) => byUsername.get(un))
      .filter(Boolean) as { id: string }[];
    await db.insert(conversationMembers).values(
      members.map((m) => ({ conversationId: c.id, userId: m.id }))
    );
    await db.insert(messages).values(
      t.msgs.map((m) => ({
        conversationId: c.id,
        senderId: byUsername.get(m.from)!.id,
        body: m.body,
      }))
    );
  }
}
