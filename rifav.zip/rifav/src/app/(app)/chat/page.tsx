"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { timeAgo } from "@/lib/utils";

type Conv = { id: string; name: string; isGroup: boolean; displayName: string; avatar: string; members: any[]; lastMessage: any };

export default function ChatListPage() {
  const router = useRouter();
  const [conversations, setConversations] = useState<Conv[]>([]);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/auth/me").then(r => r.json()).then(d => { if (!d.user) router.push("/login"); });
  }, [router]);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/conversations", { cache: "no-store" });
    const data = await res.json();
    setConversations(data.conversations || []);
    setLoading(false);
  }, []);

  const loadUsers = useCallback(async () => {
    const res = await fetch("/api/users", { cache: "no-store" });
    const data = await res.json();
    setUsers(data.users || []);
  }, []);

  useEffect(() => { load(); loadUsers(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load, loadUsers]);

  const startOneOnOne = async (otherId: string) => {
    const res = await fetch("/api/conversations", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ memberIds: [otherId], isGroup: false }) });
    const data = await res.json();
    if (data.conversationId) window.location.href = `/chat/${data.conversationId}`;
  };

  return (
    <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm overflow-hidden">
        <header className="px-4 sm:px-5 py-3 border-b border-slate-200">
          <h1 className="text-xl font-bold">Messages</h1>
          <p className="text-xs text-slate-500">Catch up with friends</p>
        </header>
        {loading ? <div className="p-8 text-center text-slate-500">Loading…</div> : conversations.length === 0 ? (
          <div className="p-10 text-center">
            <h3 className="font-semibold">No conversations yet</h3>
            <p className="text-sm text-slate-500 mt-1">Start a new chat with someone below</p>
          </div>
        ) : (
          <ul className="divide-y divide-slate-200">
            {conversations.map((c) => (
              <li key={c.id}>
                <Link href={`/chat/${c.id}`} className="flex items-center gap-3 p-4 hover:bg-slate-50">
                  {c.isGroup ? <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 text-white grid place-items-center font-semibold">{c.displayName[0]?.toUpperCase() || "G"}</div> : <img src={c.avatar} alt="" className="h-12 w-12 rounded-full ring-1 ring-slate-200 object-cover" />}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold truncate">{c.displayName}</span>
                      {c.lastMessage && <span className="text-[11px] text-slate-500 ml-2 shrink-0">{timeAgo(c.lastMessage.createdAt)}</span>}
                    </div>
                    <p className="text-sm truncate text-slate-700">{c.lastMessage ? <>{c.lastMessage.fromMe && <span className="text-slate-400">You: </span>}{c.lastMessage.body}</> : <span className="text-slate-400">No messages yet</span>}</p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
      {users.length > 0 && (
        <div className="mt-4 rounded-3xl bg-white border border-slate-200/70 p-4">
          <h2 className="text-sm font-semibold text-slate-700 mb-2">Start a chat</h2>
          <div className="space-y-1">
            {users.map((u) => (
              <button key={u.id} onClick={() => startOneOnOne(u.id)} className="w-full flex items-center gap-3 rounded-2xl px-2 py-2 hover:bg-slate-50 text-left">
                <img src={u.avatarUrl} alt="" className="h-9 w-9 rounded-full ring-1 ring-slate-200" />
                <div className="flex-1 min-w-0"><div className="text-sm font-semibold truncate">{u.displayName}</div><div className="text-xs text-slate-500 truncate">@{u.username}</div></div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
