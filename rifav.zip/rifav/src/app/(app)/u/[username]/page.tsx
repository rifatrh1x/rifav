"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";

type ProfileUser = { id: string; username: string; displayName: string; bio: string; avatarUrl: string; followerCount: number; followingCount: number; postCount: number; isFollowing: boolean; isMe: boolean };
type Post = { id: string; mediaUrl: string; mediaType: string; caption: string; createdAt: string; likeCount: number };

export default function PublicProfilePage() {
  const { username } = useParams<{ username: string }>();
  const router = useRouter();
  const [profile, setProfile] = useState<ProfileUser | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const me = await fetch("/api/auth/me", { cache: "no-store" }).then(r => r.json()).then(d => d.user).catch(() => null);
      setIsLoggedIn(!!me);
      const res = await fetch(`/api/search?q=${encodeURIComponent(username as string)}`, { cache: "no-store" });
      const data = await res.json();
      const u = (data.users || []).find((u: { username: string }) => u.username === username);
      if (!u) { setProfile(null); setLoading(false); return; }
      const r2 = await fetch(`/api/users/${u.id}`, { cache: "no-store" });
      const d2 = await r2.json();
      setProfile(d2.user);
      setPosts(d2.posts || []);
    } catch { setProfile(null); }
    setLoading(false);
  }, [username]);

  useEffect(() => { load(); }, [load]);

  const toggleFollow = async () => {
    if (!profile || busy) return;
    if (!isLoggedIn) { router.push("/login"); return; }
    setBusy(true);
    const wasFollowing = profile.isFollowing;
    setProfile({ ...profile, isFollowing: !wasFollowing, followerCount: profile.followerCount + (wasFollowing ? -1 : 1) });
    try { const res = await fetch(`/api/users/${profile.id}/follow`, { method: wasFollowing ? "DELETE" : "POST" }); if (!res.ok) throw new Error(); } catch { setProfile(profile); } finally { setBusy(false); }
  };

  const startChat = async () => {
    if (!profile) return;
    if (!isLoggedIn) { router.push("/login"); return; }
    const res = await fetch("/api/conversations", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ memberIds: [profile.id], isGroup: false }) });
    const data = await res.json();
    if (data.conversationId) router.push(`/chat/${data.conversationId}`);
  };

  if (loading) return <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4"><div className="rounded-3xl bg-white border border-slate-200 p-8 rifav-shimmer h-44" /></div>;
  if (!profile) return <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-10 text-center"><h1 className="text-2xl font-bold">User not found</h1><p className="text-slate-500 mt-1">@{username} doesn't exist on rifav.</p><Link href="/" className="mt-4 inline-block rounded-2xl bg-slate-900 text-white text-sm font-semibold px-4 py-2">Back to home</Link></div>;

  return (
    <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm overflow-hidden">
        <div className="h-28 sm:h-36 bg-gradient-to-r from-fuchsia-500 via-indigo-500 to-rose-500" />
        <div className="px-4 sm:px-6 pb-5 -mt-12 sm:-mt-14">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            <img src={profile.avatarUrl} alt="" className="h-24 w-24 sm:h-28 sm:w-28 rounded-full ring-4 ring-white object-cover shadow" />
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold tracking-tight truncate">{profile.displayName}</h1>
              <p className="text-sm text-slate-500">@{profile.username}</p>
              {profile.bio && <p className="mt-2 text-sm text-slate-700 whitespace-pre-wrap">{profile.bio}</p>}
              <div className="mt-3 flex items-center gap-5 text-sm text-slate-600">
                <span><strong className="text-slate-900">{profile.postCount}</strong> posts</span>
                <span><strong className="text-slate-900">{profile.followerCount}</strong> followers</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {profile.isMe ? <Link href="/profile" className="rounded-2xl border border-slate-200 text-sm font-semibold px-4 py-2">Edit</Link> : (
                <>
                  <button onClick={toggleFollow} disabled={busy} className={"rounded-2xl text-sm font-semibold px-4 py-2 " + (profile.isFollowing ? "border border-slate-200 text-slate-700" : "bg-slate-900 text-white")}>{profile.isFollowing ? "Following" : "Follow"}</button>
                  <button onClick={startChat} className="rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 py-2">Message</button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="mt-6">
        <h2 className="text-sm font-semibold text-slate-700 px-1 mb-3">Posts</h2>
        {posts.length === 0 ? <p className="text-sm text-slate-500">No posts yet.</p> : (
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
            {posts.map((p) => <div key={p.id} className="relative aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200"><img src={p.mediaUrl} alt="" className="w-full h-full object-cover" /></div>)}
          </div>
        )}
      </div>
    </div>
  );
}
