"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";
import { cls, placeholderImage, timeAgo } from "@/lib/utils";

type DraftPost = { caption: string; mediaType: "image" | "video"; mediaUrl: string; preview: string };
const SAMPLE_PALETTES = 12;

export default function UploadPage() {
  const { user } = useAuth();
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [draft, setDraft] = useState<DraftPost | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<any[]>([]);
  const [loadingRecent, setLoadingRecent] = useState(true);

  useEffect(() => { if (!user) { router.push("/login"); return; } }, [user, router]);

  const loadRecent = async () => {
    if (!user) return;
    setLoadingRecent(true);
    const res = await fetch(`/api/posts?scope=user&userId=${user.id}`, { cache: "no-store" });
    const data = await res.json();
    setRecent((data.posts || []).slice(0, 6));
    setLoadingRecent(false);
  };

  useEffect(() => { if (user) loadRecent(); }, [user?.id]);

  if (!user) return null;

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("image/") && !f.type.startsWith("video/")) { setError("Please choose an image or video file."); return; }
    setError(null);
    const reader = new FileReader();
    reader.onload = () => { setDraft({ caption: "", mediaType: f.type.startsWith("video/") ? "video" : "image", mediaUrl: reader.result as string, preview: URL.createObjectURL(f) }); };
    reader.readAsDataURL(f);
  };

  const useSample = (i: number, kind: "image" | "video") => {
    setError(null);
    const url = placeholderImage(`sample-${user.id}-${i}-${Date.now()}`, kind);
    setDraft({ caption: "", mediaType: kind, mediaUrl: url, preview: url });
  };

  const submit = async () => {
    if (!draft || busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/posts", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ caption: draft.caption, mediaType: draft.mediaType, mediaUrl: draft.mediaUrl }) });
      if (!res.ok) throw new Error((await res.json()).error || "Upload failed");
      setDraft(null);
      await loadRecent();
      router.push("/home");
    } catch (e) { setError(e instanceof Error ? e.message : "Failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="mx-auto max-w-2xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm p-4 sm:p-6">
        <h1 className="text-2xl font-bold tracking-tight">Create a post</h1>
        <p className="text-sm text-slate-500 mt-1">Share a photo or a video. Add a caption to give it some story.</p>
        {!draft ? (
          <div className="mt-6">
            <button onClick={() => fileRef.current?.click()} className="w-full rounded-3xl border-2 border-dashed border-slate-300 hover:border-indigo-400 hover:bg-indigo-50/50 p-10 text-center transition">
              <p className="mt-3 font-semibold text-slate-800">Click to upload</p>
              <p className="text-sm text-slate-500">JPG, PNG, MP4, MOV</p>
            </button>
            <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={onFile} />
            {error && <p className="mt-3 text-sm text-rose-600">{error}</p>}
            <div className="mt-8">
              <h2 className="text-sm font-semibold text-slate-700">Or pick a sample</h2>
              <div className="mt-3 grid grid-cols-3 sm:grid-cols-4 gap-2">
                {Array.from({ length: SAMPLE_PALETTES }).map((_, i) => <SampleTile key={i} index={i} onPick={useSample} />)}
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-6 grid sm:grid-cols-2 gap-5">
            <div>
              <div className="rounded-2xl overflow-hidden bg-slate-100 border border-slate-200">
                <img src={draft.preview} alt="preview" className="w-full max-h-[420px] object-cover" />
              </div>
              <button onClick={() => setDraft(null)} className="mt-2 text-xs text-slate-500 hover:underline">Choose different</button>
            </div>
            <div>
              <textarea value={draft.caption} onChange={(e) => setDraft({ ...draft, caption: e.target.value })} placeholder="Write a caption…" rows={6} maxLength={1000} className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300 resize-none" />
              {error && <p className="mt-2 text-sm text-rose-600">{error}</p>}
              <button onClick={submit} disabled={busy} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white font-semibold text-sm px-5 py-2.5 disabled:opacity-50">{busy ? "Sharing…" : "Share post"}</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SampleTile({ index, onPick }: { index: number; onPick: (i: number, k: "image" | "video") => void }) {
  const kind: "image" | "video" = index % 4 === 0 ? "video" : "image";
  const url = placeholderImage(`tile-${index}`, kind);
  return (
    <button onClick={() => onPick(index, kind)} className="relative aspect-square rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 hover:ring-2 hover:ring-indigo-300 transition">
      <img src={url} alt="" className="w-full h-full object-cover" />
    </button>
  );
}
