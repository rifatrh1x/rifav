"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuth();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(identifier, password);
      router.push("/home");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex relative overflow-hidden bg-gradient-to-br from-indigo-600 via-fuchsia-500 to-rose-500 text-white p-12 flex-col justify-between">
        <div>
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-2xl bg-white/15 backdrop-blur grid place-items-center text-white font-extrabold text-lg">r</div>
            <span className="text-2xl font-extrabold tracking-tight">rifav</span>
          </div>
          <h1 className="mt-16 text-5xl font-extrabold leading-tight tracking-tight">Share the moments<br />worth keeping.</h1>
          <p className="mt-5 text-white/85 text-lg max-w-md">A clean, friendly home for your photos, videos, and chats. Built for everyday creators.</p>
        </div>
      </div>
      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md">
          <div className="lg:hidden mb-8 flex items-center gap-2">
            <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 grid place-items-center text-white font-extrabold">r</div>
            <span className="text-2xl font-extrabold tracking-tight">rifav</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight">Welcome back</h2>
          <p className="mt-2 text-slate-500">Log in to your rifav account to keep sharing.</p>
          <form onSubmit={onSubmit} className="mt-8 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Username or email</label>
              <input value={identifier} onChange={(e) => setIdentifier(e.target.value)} className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" placeholder="rifav or you@rifav.app" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300" placeholder="••••••••" required />
            </div>
            {error && <p className="text-sm text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">{error}</p>}
            <button type="submit" disabled={busy} className="w-full rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 transition disabled:opacity-60">{busy ? "Logging in…" : "Log in"}</button>
          </form>
          <div className="mt-6 rounded-2xl bg-indigo-50 border border-indigo-100 p-4 text-sm">
            <p className="font-semibold text-indigo-900">Try the demo</p>
            <p className="text-indigo-800/80 mt-1">Username <span className="font-mono">rifav</span> · Password <span className="font-mono">password123</span></p>
            <button type="button" onClick={() => { setIdentifier("rifav"); setPassword("password123"); }} className="mt-2 text-xs font-semibold text-indigo-700 hover:underline">Fill demo credentials →</button>
          </div>
          <p className="mt-6 text-sm text-slate-600 text-center">New to rifav?{" "}<Link href="/signup" className="font-semibold text-indigo-600 hover:underline">Create an account</Link></p>
        </div>
      </div>
    </div>
  );
}
