import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { posts, users, likes, comments, follows } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { placeholderImage } from "@/lib/utils";
import { desc, eq, inArray } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const me = await getCurrentUser();
    const url = new URL(req.url);
    const scope = url.searchParams.get("scope") || "explore";
    const userId = url.searchParams.get("userId") || undefined;
    const limit = Math.min(parseInt(url.searchParams.get("limit") || "30", 10), 50);

    let baseQuery;
    if (scope === "user" && userId) {
      baseQuery = db.select().from(posts).where(eq(posts.userId, userId)).orderBy(desc(posts.createdAt)).limit(limit);
    } else if (scope === "feed" && me) {
      const f = await db.select({ id: follows.followingId }).from(follows).where(eq(follows.followerId, me.id));
      const followingIds = f.map((r) => r.id);
      const ids = Array.from(new Set([me.id, ...followingIds]));
      baseQuery = db.select().from(posts).where(inArray(posts.userId, ids)).orderBy(desc(posts.createdAt)).limit(limit);
    } else {
      baseQuery = db.select().from(posts).orderBy(desc(posts.createdAt)).limit(limit);
    }

    const items = await baseQuery;
    if (items.length === 0) return NextResponse.json({ posts: [] });

    const authorIds = Array.from(new Set(items.map((p) => p.userId)));
    const postIds = items.map((p) => p.id);

    const authorRows = await db.select().from(users).where(inArray(users.id, authorIds));
    const likeRows = await db.select().from(likes).where(inArray(likes.postId, postIds));
    const likedByMe = me ? new Set(likeRows.filter((l) => l.userId === me.id).map((l) => l.postId)) : new Set<string>();
    const likeCount = new Map<string, number>();
    for (const l of likeRows) likeCount.set(l.postId, (likeCount.get(l.postId) || 0) + 1);

    const commentRows = await db.select().from(comments).where(inArray(comments.postId, postIds));
    const commentCount = new Map<string, number>();
    for (const c of commentRows) commentCount.set(c.postId, (commentCount.get(c.postId) || 0) + 1);

    const authors = new Map(authorRows.map((a) => [a.id, a]));
    const result = items.map((p) => {
      const a = authors.get(p.userId)!;
      return {
        id: p.id, caption: p.caption, mediaType: p.mediaType, mediaUrl: p.mediaUrl, createdAt: p.createdAt,
        likeCount: likeCount.get(p.id) || 0, commentCount: commentCount.get(p.id) || 0, likedByMe: likedByMe.has(p.id),
        author: { id: a.id, username: a.username, displayName: a.displayName, avatarUrl: a.avatarUrl },
      };
    });
    return NextResponse.json({ posts: result });
  } catch (e) {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in to post" }, { status: 401 });
  try {
    const body = await req.json();
    const caption: string = (body.caption || "").toString().slice(0, 1000);
    const mediaType: "image" | "video" = body.mediaType === "video" ? "video" : "image";
    let mediaUrl: string = (body.mediaUrl || "").toString();
    if (!mediaUrl) mediaUrl = placeholderImage(`${me.id}-${Date.now()}-${caption}`, mediaType);
    const [p] = await db.insert(posts).values({ userId: me.id, caption, mediaType, mediaUrl }).returning();
    return NextResponse.json({
      post: { id: p.id, caption: p.caption, mediaType: p.mediaType, mediaUrl: p.mediaUrl, createdAt: p.createdAt, likeCount: 0, commentCount: 0, likedByMe: false, author: { id: me.id, username: me.username, displayName: me.displayName, avatarUrl: me.avatarUrl } },
    });
  } catch (e) {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  const [p] = await db.select().from(posts).where(eq(posts.id, id)).limit(1);
  if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (p.userId !== me.id) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  await db.delete(posts).where(eq(posts.id, id));
  return NextResponse.json({ ok: true });
}
