import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { posts, comments, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq, desc, inArray } from "drizzle-orm";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const [p] = await db.select().from(posts).where(eq(posts.id, id)).limit(1);
    if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const rows = await db.select().from(comments).where(eq(comments.postId, id)).orderBy(desc(comments.createdAt)).limit(100);
    const userIds = Array.from(new Set(rows.map((r) => r.userId)));
    const authors = userIds.length ? await db.select().from(users).where(inArray(users.id, userIds)) : [];
    const aMap = new Map(authors.map((a) => [a.id, a]));
    return NextResponse.json({
      comments: rows.map((c) => {
        const a = aMap.get(c.userId)!;
        return { id: c.id, body: c.body, createdAt: c.createdAt, author: { id: a.id, username: a.username, displayName: a.displayName, avatarUrl: a.avatarUrl } };
      }),
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in to comment" }, { status: 401 });
  const { id } = await ctx.params;
  try {
    const body = await req.json();
    const text: string = (body.body || "").toString().slice(0, 500);
    if (!text.trim()) return NextResponse.json({ error: "Empty comment" }, { status: 400 });
    const [p] = await db.select().from(posts).where(eq(posts.id, id)).limit(1);
    if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const [c] = await db.insert(comments).values({ postId: id, userId: me.id, body: text }).returning();
    return NextResponse.json({ comment: { id: c.id, body: c.body, createdAt: c.createdAt, author: { id: me.id, username: me.username, displayName: me.displayName, avatarUrl: me.avatarUrl } } });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
