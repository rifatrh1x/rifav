import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, conversationMembers, messages, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { and, desc, eq, inArray } from "drizzle-orm";

export async function GET() {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in" }, { status: 401 });
  try {
    const myConvs = await db.select({ id: conversations.id, name: conversations.name, isGroup: conversations.isGroup, createdAt: conversations.createdAt }).from(conversationMembers).innerJoin(conversations, eq(conversations.id, conversationMembers.conversationId)).where(eq(conversationMembers.userId, me.id)).orderBy(desc(conversations.createdAt));
    const ids = myConvs.map((c) => c.id);
    let membersByConv = new Map<string, any[]>();
    let lastByConv = new Map<string, any>();
    if (ids.length) {
      const allMembers = await db.select({ conversationId: conversationMembers.conversationId, user: { id: users.id, username: users.username, displayName: users.displayName, avatarUrl: users.avatarUrl } }).from(conversationMembers).innerJoin(users, eq(users.id, conversationMembers.userId)).where(inArray(conversationMembers.conversationId, ids));
      for (const m of allMembers) { const arr = membersByConv.get(m.conversationId) || []; arr.push(m.user); membersByConv.set(m.conversationId, arr); }
      const lastMsgs = await db.select().from(messages).where(inArray(messages.conversationId, ids)).orderBy(desc(messages.createdAt));
      for (const m of lastMsgs) { if (!lastByConv.has(m.conversationId)) lastByConv.set(m.conversationId, { body: m.body, createdAt: m.createdAt, senderId: m.senderId }); }
    }
    const result = myConvs.map((c) => {
      const members = membersByConv.get(c.id) || [];
      const others = members.filter((m) => m.id !== me.id);
      const displayName = c.isGroup ? c.name || (members.length > 0 ? `Group (${members.length})` : "Group") : others[0]?.displayName || "Conversation";
      const avatar = c.isGroup ? "" : others[0]?.avatarUrl || "";
      const last = lastByConv.get(c.id);
      return { id: c.id, name: c.name, isGroup: c.isGroup, displayName, avatar, members, lastMessage: last ? { body: last.body, createdAt: last.createdAt, fromMe: last.senderId === me.id } : null };
    });
    return NextResponse.json({ conversations: result });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Please log in" }, { status: 401 });
  try {
    const body = await req.json();
    const memberIds: string[] = Array.isArray(body.memberIds) ? body.memberIds : [];
    const isGroup = !!body.isGroup;
    const name: string = (body.name || "").toString().slice(0, 60);
    const unique = Array.from(new Set([me.id, ...memberIds])).filter(Boolean);
    if (unique.length < 2) return NextResponse.json({ error: "Need at least one other member" }, { status: 400 });
    const [c] = await db.insert(conversations).values({ isGroup, name: isGroup ? name : "" }).returning();
    await db.insert(conversationMembers).values(unique.map((uid) => ({ conversationId: c.id, userId: uid })));
    return NextResponse.json({ conversationId: c.id });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
