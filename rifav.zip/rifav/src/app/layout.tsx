import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Providers } from "@/components/Providers";

export const metadata: Metadata = {
  title: "rifav — share your story",
  description: "rifav is a place to share photos, videos, and moments with people you care about.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#f7f7f8] text-slate-900 antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
