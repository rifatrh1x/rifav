export function timeAgo(date: Date | string) {
  const d = typeof date === "string" ? new Date(date) : date;
  const seconds = Math.floor((Date.now() - d.getTime()) / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d`;
  const weeks = Math.floor(days / 7);
  if (weeks < 4) return `${weeks}w`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months}mo`;
  return `${Math.floor(days / 365)}y`;
}

export function cls(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

export function placeholderImage(seed: string, kind: "image" | "video" = "image") {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  const palettes = [
    ["#fb7185", "#f97316", "#f59e0b"],
    ["#22d3ee", "#3b82f6", "#8b5cf6"],
    ["#34d399", "#10b981", "#0ea5e9"],
    ["#f472b6", "#a855f7", "#6366f1"],
    ["#fde68a", "#f97316", "#dc2626"],
    ["#a7f3d0", "#22d3ee", "#6366f1"],
    ["#fda4af", "#f0abfc", "#a78bfa"],
    ["#67e8f9", "#818cf8", "#c084fc"],
  ];
  const p = palettes[h % palettes.length];
  const a = (h % 100) + 100;
  const b = ((h >> 3) % 80) + 60;
  const c = ((h >> 5) % 70) + 40;
  const rot = (h % 60) - 30;
  const svg = `<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600" preserveAspectRatio="xMidYMid slice">
<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
<stop offset="0%" stop-color="${p[0]}"/>
<stop offset="50%" stop-color="${p[1]}"/>
<stop offset="100%" stop-color="${p[2]}"/>
</linearGradient>
<filter id="b"><feGaussianBlur stdDeviation="40"/></filter>
</defs>
<rect width="600" height="600" fill="url(#bg)"/>
<g filter="url(#b)" opacity="0.55">
<circle cx="${a}" cy="${a}" r="${b}" fill="#fff"/>
<rect x="${600 - c}" y="${400 - c}" width="${c * 1.6}" height="${c * 1.6}" fill="#000" opacity="0.18" transform="rotate(${rot} 300 300)"/>
<circle cx="${600 - a}" cy="${b}" r="${c}" fill="#fff" opacity="0.5"/>
</g>
<g opacity="0.18" fill="#fff">
<circle cx="500" cy="120" r="6"/>
<circle cx="80" cy="500" r="4"/>
<circle cx="320" cy="540" r="3"/>
<circle cx="120" cy="160" r="5"/>
</g>
${
  kind === "video"
    ? `<g transform="translate(300 300)"><circle r="50" fill="rgba(0,0,0,0.45)"/><polygon points="-14,-22 28,0 -14,22" fill="#fff"/></g>`
    : ""
}
</svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
