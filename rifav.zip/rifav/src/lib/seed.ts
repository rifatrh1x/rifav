import { db } from "@/db";
import {
  users,
  posts,
  likes,
  comments,
  follows,
  conversations,
  conversationMembers,
  messages,
} from "@/db/schema";
import { hashPassword, avatarFor } from "@/lib/auth";
import { placeholderImage } from "@/lib/utils";
import { sql } from "drizzle-orm";

const DEMO_PASSWORD = "password123";

const PEOPLE = [
  { username: "rifav", displayName: "Rifav Ahmed", bio: "Building rifav — the home for creators ✨" },
  { username: "ava.carter", displayName: "Ava Carter", bio: "Photographer · Traveler · Coffee snob ☕📷" },
  { username: "leo.martin", displayName: "Leo Martin", bio: "Indie game dev. Working on something big 🎮" },
  { username: "mira.kapoor", displayName: "Mira Kapoor", bio: "Recipe creator & food stylist. Veg-friendly 🌱" },
  { username: "theo.b", displayName: "Theo Bennett", bio: "Filmmaker. Cinema is my love language 🎬" },
  { username: "sana.q", displayName: "Sana Qureshi", bio: "Designer · Plant mom · Cat lady 🌿🐈" },
  { username: "kenji.t", displayName: "Kenji Tanaka", bio: "Skateboarder & sneaker collector 🛹" },
  { username: "nina.rose", displayName: "Nina Rossi", bio: "Yoga instructor. Find me on the mat 🧘‍♀️" },
];

const CAPTIONS = [
  "Sunset chase in the city tonight 🌇",
  "Finally got the new lens — obsessed.",
  "Cooked this up after a long day. Worth it.",
  "Skating laps at the new park. So smooth.",
  "Studio days hit different when the light's right.",
  "Brunch with the best people. So grateful 🥞",
  "Hiking through the pines. Air up here is unreal.",
  "Late night edits. Coffee #4 fueling the grind.",
  "Throwback to last summer. Wild how fast it flew.",
  "Field trip with the crew. No laptops allowed.",
  "First snow of the season. Cozy mode: ON ❄️",
  "Street art is the best free museum.",
  "New sketchbook, new pages, new possibilities.",
  "Just dropped a new reel — go watch it 🎬",
  "Today I learned something and it broke my brain.",
  "The dogs got a new friend today. Meet Mochi 🐶",
  "Tiny desk setup, big dreams.",
  "Camera roll dump. Pick a favorite.",
  "When the algorithm finally blessed you 😂",
  "I make things. Sometimes they're even good.",
];

const CHAT_THREADS = [
  {
    name: "",
    isGroup: false,
    members: ["rifav", "ava.carter"],
    msgs: [
      { from: "ava.carter", body: "Hey! Loved your latest post 💛" },
      { from: "rifav", body: "Thank you so much! Yours too — the rooftop shot was unreal." },
    ],
  },
  {
    name: "Creator Hangout",
    isGroup: true,
    members: ["rifav", "ava.carter", "leo.martin", "theo.b", "mira.kapoor"],
    msgs: [
      { from: "leo.martin", body: "Game night at my place Friday?" },
      { from: "theo.b", body: "I'm in if we do Mario Kart" },
      { from: "rifav", body: "8pm works. I'll grab drinks." },
    ],
  },
];

export async function seedIfEmpty() {
  try {
    const result = await db.execute(sql`select count(*)::int as count from users`);
    const count = (result.rows[0] as any)?.count || 0;
    if (count > 0) return;
  } catch {
    return;
  }

  const pw = await hashPassword(DEMO_PASSWORD);
  const userRows = await db
    .insert(users)
    .values(
      PEOPLE.map((p) => ({
        username: p.username,
        email: `${p.username}@rifav.app`,
        passwordHash: pw,
        displayName: p.displayName,
        bio: p.bio,
        avatarUrl: avatarFor(p.displayName),
      }))
    )
    .returning();

  const byUsername = new Map(userRows.map((u) => [u.username, u]));

  const allPosts: { id: string; userId: string }[] = [];
  let postIdx = 0;
  for (const u of userRows) {
    const numPosts = 2 + (u.username.length % 2);
    for (let i = 0; i < numPosts; i++) {
      const caption = CAPTIONS[(postIdx + i) % CAPTIONS.length];
      const kind = i % 4 === 0 ? "video" : "image";
      const [p] = await db
        .insert(posts)
        .values({
          userId: u.id,
          caption,
          mediaType: kind,
          mediaUrl: placeholderImage(`${u.username}-${i}`, kind as "image" | "video"),
        })
        .returning();
      allPosts.push({ id: p.id, userId: u.id });
    }
    postIdx += 3;
  }

  const likeRows: { userId: string; postId: string }[] = [];
  for (const u of userRows) {
    const candidates = allPosts.filter((p) => p.userId !== u.id);
    for (let i = 0; i < 3; i++) {
      const pick = candidates[i % candidates.length];
      if (!likeRows.some((l) => l.userId === u.id && l.postId === pick.id)) {
        likeRows.push({ userId: u.id, postId: pick.id });
      }
    }
  }
  if (likeRows.length) await db.insert(likes).values(likeRows);

  const followRows: { followerId: string; followingId: string }[] = [];
  const rifav = byUsername.get("rifav")!;
  for (const u of userRows) {
    if (u.id !== rifav.id) {
      followRows.push({ followerId: rifav.id, followingId: u.id });
      followRows.push({ followerId: u.id, followingId: rifav.id });
    }
  }
  if (followRows.length) await db.insert(follows).values(followRows);

  for (const t of CHAT_THREADS) {
    const [c] = await db
      .insert(conversations)
      .values({ isGroup: t.isGroup, name: t.name })
      .returning();
    const members = t.members.map((un) => byUsername.get(un)!).filter(Boolean);
    await db.insert(conversationMembers).values(
      members.map((m) => ({ conversationId: c.id, userId: m.id }))
    );
    await db.insert(messages).values(
      t.msgs.map((m) => ({
        conversationId: c.id,
        senderId: byUsername.get(m.from)!.id,
        body: m.body,
      }))
    );
  }
}
