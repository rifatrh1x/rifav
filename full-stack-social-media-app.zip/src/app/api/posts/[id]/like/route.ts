import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { posts, likes } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { and, eq } from "drizzle-orm";

export async function POST(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const [p] = await db.select().from(posts).where(eq(posts.id, id)).limit(1);
  if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
  // upsert: insert if not exists
  const existing = await db
    .select()
    .from(likes)
    .where(and(eq(likes.userId, me.id), eq(likes.postId, id)))
    .limit(1);
  if (existing.length === 0) {
    await db.insert(likes).values({ userId: me.id, postId: id });
  }
  return NextResponse.json({ ok: true, liked: true });
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  await db
    .delete(likes)
    .where(and(eq(likes.userId, me.id), eq(likes.postId, id)));
  return NextResponse.json({ ok: true, liked: false });
}
