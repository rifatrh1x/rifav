import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { hashPassword, createSession, avatarFor } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const { username, email, password, displayName } = await req.json();
  if (!username || !email || !password || !displayName) {
    return NextResponse.json({ error: "All fields are required" }, { status: 400 });
  }
  if (password.length < 6) {
    return NextResponse.json({ error: "Password must be at least 6 characters" }, { status: 400 });
  }
  const existing = await db
    .select()
    .from(users)
    .where(or(eq(users.username, username.toLowerCase()), eq(users.email, email.toLowerCase())))
    .limit(1);
  if (existing.length) {
    return NextResponse.json({ error: "Username or email already in use" }, { status: 409 });
  }
  const hash = await hashPassword(password);
  const [u] = await db
    .insert(users)
    .values({
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      passwordHash: hash,
      displayName,
      bio: "",
      avatarUrl: avatarFor(displayName),
    })
    .returning();
  await createSession(u.id);
  return NextResponse.json({
    user: {
      id: u.id,
      username: u.username,
      email: u.email,
      displayName: u.displayName,
      bio: u.bio,
      avatarUrl: u.avatarUrl,
    },
  });
}
