import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, posts } from "@/db/schema";
import { or, ilike, desc, eq, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const q = (url.searchParams.get("q") || "").trim();
  if (!q) return NextResponse.json({ users: [], posts: [] });

  const pat = `%${q}%`;

  const userRows = await db
    .select()
    .from(users)
    .where(or(ilike(users.username, pat), ilike(users.displayName, pat)))
    .limit(20);

  const postRows = await db
    .select()
    .from(posts)
    .where(ilike(posts.caption, pat))
    .orderBy(desc(posts.createdAt))
    .limit(20);

  return NextResponse.json({
    users: userRows.map((u) => ({
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      bio: u.bio,
      avatarUrl: u.avatarUrl,
    })),
    posts: postRows.map((p) => ({
      id: p.id,
      caption: p.caption,
      mediaType: p.mediaType,
      mediaUrl: p.mediaUrl,
      createdAt: p.createdAt,
    })),
  });
}
