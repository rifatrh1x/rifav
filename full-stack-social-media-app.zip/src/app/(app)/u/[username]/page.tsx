"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";
import { AuthModal } from "@/components/AuthModal";
import { cls, timeAgo } from "@/lib/utils";
import Link from "next/link";

type ProfileUser = {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string;
  followerCount: number;
  followingCount: number;
  postCount: number;
  isFollowing: boolean;
  isMe: boolean;
};
type Post = { id: string; mediaUrl: string; mediaType: string; caption: string; createdAt: string; likeCount: number };

export default function PublicProfilePage() {
  const { username } = useParams<{ username: string }>();
  const router = useRouter();
  const { user: me } = useAuth();
  const [profile, setProfile] = useState<ProfileUser | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [gateOpen, setGateOpen] = useState(false);
  const [gateMsg, setGateMsg] = useState<string | undefined>(undefined);

  const requireAuth = (msg: string) => {
    if (!me) {
      setGateMsg(msg);
      setGateOpen(true);
      return false;
    }
    return true;
  };

  const load = useCallback(async () => {
    setLoading(true);
    // First lookup user by username via search
    const res = await fetch(`/api/search?q=${encodeURIComponent(username)}`, { cache: "no-store" });
    const data = await res.json();
    const u = (data.users || []).find((u: { username: string }) => u.username === username);
    if (!u) {
      setProfile(null);
      setLoading(false);
      return;
    }
    const r2 = await fetch(`/api/users/${u.id}`, { cache: "no-store" });
    const d2 = await r2.json();
    setProfile(d2.user);
    setPosts(d2.posts || []);
    setLoading(false);
  }, [username]);

  useEffect(() => {
    load();
  }, [load]);

  const toggleFollow = async () => {
    if (!profile || busy) return;
    if (!requireAuth("Log in to follow people on rifav.")) return;
    setBusy(true);
    const wasFollowing = profile.isFollowing;
    setProfile({ ...profile, isFollowing: !wasFollowing, followerCount: profile.followerCount + (wasFollowing ? -1 : 1) });
    try {
      const res = await fetch(`/api/users/${profile.id}/follow`, {
        method: wasFollowing ? "DELETE" : "POST",
      });
      if (!res.ok) throw new Error();
    } catch {
      setProfile(profile);
    } finally {
      setBusy(false);
    }
  };

  const startChat = async () => {
    if (!profile) return;
    if (!requireAuth("Log in to message people on rifav.")) return;
    const res = await fetch("/api/conversations", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ memberIds: [profile.id], isGroup: false }),
    });
    const data = await res.json();
    if (data.conversationId) router.push(`/chat/${data.conversationId}`);
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4">
        <div className="rounded-3xl bg-white border border-slate-200 p-8 rifav-shimmer h-44" />
      </div>
    );
  }
  if (!profile) {
    return (
      <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-10 text-center">
        <h1 className="text-2xl font-bold">User not found</h1>
        <p className="text-slate-500 mt-1">@{username} doesn't exist on rifav.</p>
        <Link href="/home" className="mt-4 inline-block rounded-2xl bg-slate-900 text-white text-sm font-semibold px-4 py-2">Back to home</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm overflow-hidden">
        <div className="h-28 sm:h-36 bg-gradient-to-r from-fuchsia-500 via-indigo-500 to-rose-500" />
        <div className="px-4 sm:px-6 pb-5 -mt-12 sm:-mt-14">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            <img src={profile.avatarUrl} alt="" className="h-24 w-24 sm:h-28 sm:w-28 rounded-full ring-4 ring-white object-cover shadow" />
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold tracking-tight truncate">{profile.displayName}</h1>
              <p className="text-sm text-slate-500">@{profile.username}</p>
              {profile.bio && <p className="mt-2 text-sm text-slate-700 whitespace-pre-wrap">{profile.bio}</p>}
              <div className="mt-3 flex items-center gap-5 text-sm text-slate-600">
                <span><strong className="text-slate-900">{profile.postCount}</strong> posts</span>
                <span><strong className="text-slate-900">{profile.followerCount}</strong> followers</span>
                <span><strong className="text-slate-900">{profile.followingCount}</strong> following</span>
              </div>
            </div>
            <div className="sm:self-start sm:mt-1 flex items-center gap-2">
              {profile.isMe ? (
                <Link href="/profile" className="rounded-2xl border border-slate-200 hover:border-slate-300 text-sm font-semibold px-4 py-2">Edit profile</Link>
              ) : (
                <>
                  <button
                    onClick={toggleFollow}
                    disabled={busy}
                    className={cls(
                      "rounded-2xl text-sm font-semibold px-4 py-2",
                      profile.isFollowing
                        ? "border border-slate-200 text-slate-700 hover:border-slate-300"
                        : "bg-slate-900 text-white hover:bg-slate-800",
                    )}
                  >
                    {profile.isFollowing ? "Following" : "Follow"}
                  </button>
                  <button
                    onClick={startChat}
                    className="rounded-2xl bg-indigo-600 text-white text-sm font-semibold px-4 py-2 inline-flex items-center gap-1.5"
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
                    Message
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h2 className="text-sm font-semibold text-slate-700 px-1 mb-3">Posts</h2>
        {posts.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-slate-300 p-10 text-center bg-white">
            <p className="font-semibold">No posts yet</p>
            <p className="text-sm text-slate-500 mt-1">When @{profile.username} posts, you'll see them here.</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
            {posts.map((p) => (
              <div key={p.id} className="relative aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200 group">
                <img src={p.mediaUrl} alt="" className="w-full h-full object-cover" />
                {p.mediaType === "video" && (
                  <div className="absolute top-1.5 right-1.5 rounded-full bg-black/55 p-1">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
                  </div>
                )}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition flex items-end">
                  <div className="p-2 text-white text-[11px] opacity-0 group-hover:opacity-100 transition">
                    {p.caption.slice(0, 60) || "—"} · {timeAgo(p.createdAt)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <AuthModal
        open={gateOpen}
        onClose={() => setGateOpen(false)}
        message={gateMsg || "Log in to interact on rifav."}
      />
    </div>
  );
}
