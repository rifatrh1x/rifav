"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/components/AuthContext";
import { AuthModal } from "@/components/AuthModal";
import { cls, timeAgo } from "@/lib/utils";

type Member = { id: string; username: string; displayName: string; avatarUrl: string };
type Msg = { id: string; body: string; createdAt: string; senderId: string };

export default function ChatThreadPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();
  const [members, setMembers] = useState<Member[]>([]);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [conv, setConv] = useState<{ name: string; isGroup: boolean } | null>(null);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [forbidden, setForbidden] = useState(false);
  const [gateOpen, setGateOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    const res = await fetch(`/api/conversations/${id}`, { cache: "no-store" });
    if (res.status === 401) {
      setForbidden(true);
      setLoading(false);
      return;
    }
    if (res.status === 403) {
      router.replace("/chat");
      return;
    }
    if (!res.ok) return;
    const data = await res.json();
    setConv(data.conversation);
    setMembers(data.members);
    setMessages(data.messages);
    setLoading(false);
    setForbidden(false);
  }, [id, router, user]);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, [load, user]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length]);

  const otherMembers = members.filter((m) => m.id !== user?.id);
  const title = conv?.isGroup
    ? conv.name || `Group (${members.length})`
    : otherMembers[0]?.displayName || "Conversation";
  const avatar = conv?.isGroup ? "" : otherMembers[0]?.avatarUrl || "";

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || busy) return;
    if (!user) {
      setGateOpen(true);
      return;
    }
    setBusy(true);
    const t = text;
    const tmp: Msg = { id: "tmp-" + Date.now(), body: t, createdAt: new Date().toISOString(), senderId: user?.id || "" };
    setMessages((m) => [...m, tmp]);
    setText("");
    try {
      const res = await fetch(`/api/conversations/${id}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ body: t }),
      });
      const data = await res.json();
      if (res.ok && data.message) {
        setMessages((m) => m.map((x) => (x.id === tmp.id ? data.message : x)));
      } else {
        // rollback
        setMessages((m) => m.filter((x) => x.id !== tmp.id));
        setText(t);
      }
    } finally {
      setBusy(false);
    }
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
        <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm p-8 sm:p-10 text-center">
          <div className="mx-auto h-16 w-16 rounded-3xl bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 grid place-items-center text-white">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
          </div>
          <h1 className="mt-4 text-2xl font-bold tracking-tight">Join the conversation</h1>
          <p className="mt-1 text-sm text-slate-500 max-w-md mx-auto">Log in to read and reply to this conversation on rifav.</p>
          <div className="mt-5 flex flex-col sm:flex-row items-center justify-center gap-2">
            <button onClick={() => setGateOpen(true)} className="w-full sm:w-auto rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold px-5 py-2.5">Log in</button>
            <button onClick={() => { setGateOpen(false); router.push("/signup"); }} className="w-full sm:w-auto rounded-2xl border border-slate-200 hover:border-slate-300 text-sm font-semibold px-5 py-2.5">Create account</button>
          </div>
        </div>
        <AuthModal open={gateOpen} onClose={() => setGateOpen(false)} initialMode="login" message="Log in to read and reply to this conversation." />
      </div>
    );
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-3xl w-full px-3 sm:px-4 py-4">
        <div className="rounded-3xl bg-white border border-slate-200 p-6 rifav-shimmer h-[60vh]" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl w-full px-0 sm:px-4 py-0 sm:py-4 pb-24 md:pb-8">
      <div className="sm:rounded-3xl bg-white sm:border sm:border-slate-200 sm:shadow-sm flex flex-col h-[calc(100vh-56px)] sm:h-[calc(100vh-120px)] overflow-hidden">
        <header className="flex items-center gap-3 px-3 sm:px-5 py-3 border-b border-slate-200 bg-white/95 backdrop-blur">
          <Link href="/chat" className="sm:hidden rounded-full p-2 hover:bg-slate-100">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6" /></svg>
          </Link>
          {conv?.isGroup ? (
            <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 text-white grid place-items-center font-semibold">
              {title[0]?.toUpperCase()}
            </div>
          ) : (
            <img src={avatar} alt="" className="h-10 w-10 rounded-full ring-1 ring-slate-200 object-cover" />
          )}
          <div className="min-w-0">
            <div className="font-semibold truncate">{title}</div>
            <div className="text-xs text-slate-500 truncate">
              {conv?.isGroup
                ? `${members.length} members`
                : `@${otherMembers[0]?.username || ""}`}
            </div>
          </div>
        </header>

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 sm:px-5 py-4 space-y-2 bg-slate-50/60">
          {messages.length === 0 && (
            <div className="text-center py-16 text-slate-500">
              <div className="mx-auto h-12 w-12 rounded-2xl bg-white border border-slate-200 grid place-items-center">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
              </div>
              <p className="mt-3 text-sm">No messages yet — say hi 👋</p>
            </div>
          )}
          {messages.map((m, i) => {
            const mine = m.senderId === user?.id;
            const prev = messages[i - 1];
            const showAvatar = !mine && (!prev || prev.senderId !== m.senderId);
            const sender = members.find((mm) => mm.id === m.senderId);
            return (
              <div key={m.id} className={cls("flex gap-2", mine ? "justify-end" : "justify-start")}>
                {!mine && (
                  <div className="w-7 shrink-0">
                    {showAvatar && (
                      <img src={sender?.avatarUrl} alt="" className="h-7 w-7 rounded-full ring-1 ring-slate-200" />
                    )}
                  </div>
                )}
                <div className={cls("max-w-[78%]")}>
                  {!mine && conv?.isGroup && showAvatar && (
                    <div className="text-[11px] text-slate-500 mb-0.5 ml-1">{sender?.displayName}</div>
                  )}
                  <div
                    className={cls(
                      "rounded-2xl px-3 py-2 text-sm whitespace-pre-wrap break-words",
                      mine
                        ? "bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white rounded-br-md"
                        : "bg-white border border-slate-200 text-slate-800 rounded-bl-md",
                    )}
                  >
                    {m.body}
                  </div>
                  <div className={cls("text-[10px] text-slate-400 mt-0.5", mine ? "text-right mr-1" : "ml-1")}>
                    {timeAgo(m.createdAt)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <form
          onSubmit={send}
          className="flex items-center gap-2 border-t border-slate-200 bg-white px-3 py-2.5"
        >
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type a message…"
            className="flex-1 rounded-2xl bg-slate-100 border border-transparent px-3 py-2 text-sm outline-none focus:bg-white focus:border-slate-200 focus:ring-2 focus:ring-indigo-200"
          />
          <button
            type="submit"
            disabled={busy || !text.trim()}
            className="rounded-2xl bg-slate-900 text-white text-sm font-semibold px-4 py-2 disabled:opacity-50 inline-flex items-center gap-1.5"
          >
            <span className="hidden sm:inline">Send</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" /></svg>
          </button>
        </form>
      </div>
    </div>
  );
}
