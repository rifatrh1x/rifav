"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";
import { AuthModal } from "@/components/AuthModal";
import { cls, placeholderImage, timeAgo } from "@/lib/utils";

type DraftPost = {
  caption: string;
  mediaType: "image" | "video";
  mediaUrl: string;
  preview: string;
};

const SAMPLE_PALETTES = 12;

export default function UploadPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [gateOpen, setGateOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [draft, setDraft] = useState<DraftPost | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<{ id: string; mediaUrl: string; mediaType: string; caption: string; createdAt: string }[]>([]);
  const [loadingRecent, setLoadingRecent] = useState(true);

  const loadRecent = async () => {
    if (!user) return;
    setLoadingRecent(true);
    const res = await fetch(`/api/posts?scope=user&userId=${user.id}`, { cache: "no-store" });
    const data = await res.json();
    setRecent((data.posts || []).slice(0, 6));
    setLoadingRecent(false);
  };

  useEffect(() => {
    if (user) loadRecent();
  }, [user?.id]);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("image/") && !f.type.startsWith("video/")) {
      setError("Please choose an image or video file.");
      return;
    }
    setError(null);
    const url = URL.createObjectURL(f);
    setDraft({
      caption: "",
      mediaType: f.type.startsWith("video/") ? "video" : "image",
      mediaUrl: url,
      preview: url,
    });
  };

  const useSample = (i: number, kind: "image" | "video") => {
    setError(null);
    const url = placeholderImage(`sample-${user?.id}-${i}-${Date.now()}`, kind);
    setDraft({ caption: "", mediaType: kind, mediaUrl: url, preview: url });
  };

  const submit = async () => {
    if (!draft || busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/posts", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          caption: draft.caption,
          mediaType: draft.mediaType,
          mediaUrl: draft.mediaUrl,
        }),
      });
      if (!res.ok) throw new Error((await res.json()).error || "Upload failed");
      setDraft(null);
      await loadRecent();
      // jump to home after a short delay so user sees the toast? Just route.
      router.push("/home");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setBusy(false);
    }
  };

  // Guest view: show a friendly sign-in prompt instead of the uploader
  if (!user) {
    return (
      <div className="mx-auto max-w-2xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
        <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm p-8 sm:p-10 text-center">
          <div className="mx-auto h-16 w-16 rounded-3xl bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 grid place-items-center text-white">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" /></svg>
          </div>
          <h1 className="mt-4 text-2xl font-bold tracking-tight">Ready to share something?</h1>
          <p className="mt-1 text-sm text-slate-500 max-w-md mx-auto">Log in or create a free rifav account to post photos, videos, and moments with the people who matter.</p>
          <div className="mt-5 flex flex-col sm:flex-row items-center justify-center gap-2">
            <button
              onClick={() => setGateOpen(true)}
              className="w-full sm:w-auto rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold px-5 py-2.5"
            >
              Log in to upload
            </button>
            <button
              onClick={() => { setGateOpen(false); router.push("/signup"); }}
              className="w-full sm:w-auto rounded-2xl border border-slate-200 hover:border-slate-300 text-sm font-semibold px-5 py-2.5"
            >
              Create account
            </button>
          </div>
        </div>
        <AuthModal
          open={gateOpen}
          onClose={() => setGateOpen(false)}
          initialMode="login"
          message="Log in to share your first post on rifav."
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl w-full px-3 sm:px-4 py-4 pb-24 md:pb-8">
      <div className="rounded-3xl bg-white border border-slate-200/70 shadow-sm p-4 sm:p-6">
        <h1 className="text-2xl font-bold tracking-tight">Create a post</h1>
        <p className="text-sm text-slate-500 mt-1">Share a photo or a video. Add a caption to give it some story.</p>

        {!draft ? (
          <div className="mt-6">
            <button
              onClick={() => fileRef.current?.click()}
              className="w-full rounded-3xl border-2 border-dashed border-slate-300 hover:border-indigo-400 hover:bg-indigo-50/50 p-10 text-center transition"
            >
              <div className="mx-auto h-14 w-14 rounded-2xl bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 grid place-items-center text-white">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" /></svg>
              </div>
              <p className="mt-3 font-semibold text-slate-800">Drag &amp; drop or click to upload</p>
              <p className="text-sm text-slate-500">JPG, PNG, MP4, MOV up to a few MB</p>
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*,video/*"
              className="hidden"
              onChange={onFile}
            />
            {error && <p className="mt-3 text-sm text-rose-600">{error}</p>}

            <div className="mt-8">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-700">Or pick a sample</h2>
                <span className="text-xs text-slate-400">demo media</span>
              </div>
              <div className="mt-3 grid grid-cols-3 sm:grid-cols-4 gap-2">
                {Array.from({ length: SAMPLE_PALETTES }).map((_, i) => (
                  <SampleTile key={i} index={i} onPick={useSample} />
                ))}
              </div>
              <p className="mt-2 text-xs text-slate-400">Sample tiles are generated artworks so you can keep exploring even without files.</p>
            </div>
          </div>
        ) : (
          <div className="mt-6 grid sm:grid-cols-2 gap-5">
            <div>
              <div className="rounded-2xl overflow-hidden bg-slate-100 border border-slate-200">
                {draft.mediaType === "image" ? (
                  <img src={draft.preview} alt="preview" className="w-full max-h-[420px] object-cover" />
                ) : (
                  <div className="relative">
                    <img src={draft.preview} alt="preview" className="w-full max-h-[420px] object-cover" />
                    <div className="absolute inset-0 grid place-items-center">
                      <div className="rounded-full bg-black/55 p-3 backdrop-blur">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <button
                onClick={() => setDraft(null)}
                className="mt-2 text-xs text-slate-500 hover:underline"
              >
                Choose a different file
              </button>
            </div>
            <div>
              <div className="flex items-center gap-3 pb-3 border-b border-slate-200">
                <img src={user?.avatarUrl} alt="" className="h-9 w-9 rounded-full ring-1 ring-slate-200" />
                <div>
                  <div className="text-sm font-semibold">{user?.displayName}</div>
                  <div className="text-xs text-slate-500">@{user?.username}</div>
                </div>
              </div>
              <textarea
                value={draft.caption}
                onChange={(e) => setDraft({ ...draft, caption: e.target.value })}
                placeholder="Write a caption…"
                rows={6}
                maxLength={1000}
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300 resize-none"
              />
              <div className="mt-1 text-right text-xs text-slate-400">{draft.caption.length}/1000</div>
              {error && <p className="mt-2 text-sm text-rose-600">{error}</p>}
              <div className="mt-4 flex items-center gap-2">
                <div className="inline-flex rounded-2xl border border-slate-200 overflow-hidden">
                  <button
                    onClick={() => setDraft({ ...draft, mediaType: "image" })}
                    className={cls("px-3 py-1.5 text-xs font-semibold", draft.mediaType === "image" ? "bg-slate-900 text-white" : "bg-white text-slate-600")}
                  >Image</button>
                  <button
                    onClick={() => setDraft({ ...draft, mediaType: "video" })}
                    className={cls("px-3 py-1.5 text-xs font-semibold", draft.mediaType === "video" ? "bg-slate-900 text-white" : "bg-white text-slate-600")}
                  >Video</button>
                </div>
                <div className="flex-1" />
                <button
                  onClick={submit}
                  disabled={busy}
                  className="rounded-2xl bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white font-semibold text-sm px-5 py-2 disabled:opacity-50"
                >
                  {busy ? "Sharing…" : "Share post"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Recent posts */}
      <div className="mt-6">
        <h2 className="text-sm font-semibold text-slate-700 px-1">Your recent posts</h2>
        {loadingRecent ? (
          <div className="grid grid-cols-3 gap-2 mt-3">
            {[0, 1, 2].map((i) => <div key={i} className="aspect-square rounded-2xl rifav-shimmer" />)}
          </div>
        ) : recent.length === 0 ? (
          <p className="text-sm text-slate-500 mt-3">You haven't posted yet. Your first one is the hardest, then it gets fun.</p>
        ) : (
          <div className="grid grid-cols-3 gap-2 mt-3">
            {recent.map((r) => (
              <div key={r.id} className="relative aspect-square rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 group">
                <img src={r.mediaUrl} alt="" className="w-full h-full object-cover" />
                {r.mediaType === "video" && (
                  <div className="absolute top-2 right-2 rounded-full bg-black/55 p-1">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
                  </div>
                )}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-2 text-white text-[11px] opacity-0 group-hover:opacity-100 transition">
                  {r.caption.slice(0, 60) || "—"} · {timeAgo(r.createdAt)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function SampleTile({ index, onPick }: { index: number; onPick: (i: number, k: "image" | "video") => void }) {
  const kind: "image" | "video" = index % 4 === 0 ? "video" : "image";
  const url = placeholderImage(`tile-${index}`, kind);
  return (
    <button
      onClick={() => onPick(index, kind)}
      className="relative aspect-square rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 hover:ring-2 hover:ring-indigo-300 transition"
    >
      <img src={url} alt="" className="w-full h-full object-cover" />
      {kind === "video" && (
        <div className="absolute top-1.5 right-1.5 rounded-full bg-black/55 p-1">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z" /></svg>
        </div>
      )}
    </button>
  );
}
