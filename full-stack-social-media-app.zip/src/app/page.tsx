import { redirect } from "next/navigation";
import { seedIfEmpty } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function RootPage() {
  await seedIfEmpty();
  redirect("/home");
}
