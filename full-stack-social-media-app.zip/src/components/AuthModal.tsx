"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";
import { cls } from "@/lib/utils";

type Mode = "login" | "signup";

export function AuthModal({
  open,
  onClose,
  initialMode = "login",
  message,
  onSuccess,
}: {
  open: boolean;
  onClose: () => void;
  initialMode?: Mode;
  message?: string;
  onSuccess?: () => void;
}) {
  const router = useRouter();
  const { login, signup } = useAuth();
  const [mode, setMode] = useState<Mode>(initialMode);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  // form state — keep both forms mounted so switching is instant
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [form, setForm] = useState({ displayName: "", username: "", email: "", password: "" });

  if (!open) return null;

  const switchMode = (m: Mode) => {
    setMode(m);
    setError("");
  };

  const submitLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(identifier, password);
      onSuccess?.();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setBusy(false);
    }
  };

  const submitSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await signup({
        displayName: form.displayName.trim(),
        username: form.username.trim().toLowerCase(),
        email: form.email.trim().toLowerCase(),
        password: form.password,
      });
      onSuccess?.();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Signup failed");
    } finally {
      setBusy(false);
    }
  };

  const goFullPage = (path: string) => {
    onClose();
    router.push(path);
  };

  return (
    <div
      className="fixed inset-0 z-40 bg-slate-900/55 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-md bg-white sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with gradient */}
        <div className="relative bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 text-white px-6 pt-6 pb-7">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 rounded-full p-2 hover:bg-white/15 transition"
            aria-label="Close"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
          <div className="h-10 w-10 rounded-2xl bg-white/15 backdrop-blur grid place-items-center font-extrabold text-lg mb-3">r</div>
          <h2 className="text-xl font-bold tracking-tight">
            {mode === "login" ? "Welcome back" : "Join rifav"}
          </h2>
          <p className="text-sm text-white/90 mt-1">
            {message || (mode === "login" ? "Log in to like, post, and chat." : "Create an account in seconds — it's free.")}
          </p>
        </div>

        {/* Tabs */}
        <div className="px-6 pt-4">
          <div className="inline-flex rounded-2xl bg-slate-100 p-1 w-full">
            <button
              onClick={() => switchMode("login")}
              className={cls("flex-1 px-3 py-1.5 text-sm rounded-xl", mode === "login" ? "bg-white shadow font-semibold text-slate-900" : "text-slate-600")}
            >
              Log in
            </button>
            <button
              onClick={() => switchMode("signup")}
              className={cls("flex-1 px-3 py-1.5 text-sm rounded-xl", mode === "signup" ? "bg-white shadow font-semibold text-slate-900" : "text-slate-600")}
            >
              Sign up
            </button>
          </div>
        </div>

        {/* Forms */}
        <div className="p-6">
          {mode === "login" ? (
            <form onSubmit={submitLogin} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Username or email</label>
                <input
                  autoFocus
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"
                  placeholder="rifav or you@rifav.app"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"
                  placeholder="••••••••"
                  required
                />
              </div>
              {error && (
                <p className="text-sm text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">{error}</p>
              )}
              <button
                type="submit"
                disabled={busy}
                className="w-full rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2.5 text-sm disabled:opacity-60"
              >
                {busy ? "Logging in…" : "Log in"}
              </button>
              <div className="rounded-2xl bg-indigo-50 border border-indigo-100 p-3 text-xs text-indigo-900">
                <div className="font-semibold">Try the demo</div>
                <div className="text-indigo-800/80 mt-0.5">username <span className="font-mono">rifav</span> · password <span className="font-mono">password123</span></div>
                <button
                  type="button"
                  onClick={() => { setIdentifier("rifav"); setPassword("password123"); }}
                  className="mt-1.5 text-[11px] font-semibold text-indigo-700 hover:underline"
                >
                  Fill demo credentials →
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={submitSignup} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Display name</label>
                <input
                  autoFocus
                  value={form.displayName}
                  onChange={(e) => setForm({ ...form, displayName: e.target.value })}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"
                  placeholder="Your name"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Username</label>
                <input
                  value={form.username}
                  onChange={(e) => setForm({ ...form, username: e.target.value })}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"
                  placeholder="lowercase, no spaces"
                  pattern="[a-z0-9._]{3,30}"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Email</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"
                  placeholder="you@example.com"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Password</label>
                <input
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-200 focus:border-indigo-300"
                  placeholder="At least 6 characters"
                  minLength={6}
                  required
                />
              </div>
              {error && (
                <p className="text-sm text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-3 py-2">{error}</p>
              )}
              <button
                type="submit"
                disabled={busy}
                className="w-full rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2.5 text-sm disabled:opacity-60"
              >
                {busy ? "Creating account…" : "Create account"}
              </button>
            </form>
          )}

          <p className="mt-4 text-center text-xs text-slate-500">
            {mode === "login" ? "New to rifav?" : "Already have an account?"}{" "}
            <button
              type="button"
              onClick={() => switchMode(mode === "login" ? "signup" : "login")}
              className="font-semibold text-indigo-600 hover:underline"
            >
              {mode === "login" ? "Create one" : "Log in"}
            </button>
            <span className="mx-1">·</span>
            <button
              type="button"
              onClick={() => goFullPage(mode === "login" ? "/login" : "/signup")}
              className="text-slate-500 hover:underline"
            >
              Open full page
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

// Helper hook to gate actions behind auth
export function useAuthGate() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState<string | undefined>(undefined);

  const gate = (msg?: string): boolean => {
    if (!user) {
      setMessage(msg);
      setOpen(true);
      return false;
    }
    return true;
  };

  return {
    user,
    isOpen: open,
    message,
    openModal: (msg?: string) => {
      setMessage(msg);
      setOpen(true);
    },
    closeModal: () => setOpen(false),
    gate,
    Modal: () => <AuthModal open={open} onClose={() => setOpen(false)} message={message} />,
  };
}
