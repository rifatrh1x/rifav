"use client";

import { AuthProvider } from "@/components/AuthContext";
import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";

export function Providers({ children }: { children: React.ReactNode }) {
  return <AuthProvider>{children}</AuthProvider>;
}
