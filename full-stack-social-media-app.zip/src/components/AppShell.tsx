"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";
import { cls } from "@/lib/utils";

const NAV = [
  { href: "/home", label: "Home", icon: "home" },
  { href: "/search", label: "Search", icon: "search" },
  { href: "/upload", label: "Upload", icon: "upload" },
  { href: "/chat", label: "Chat", icon: "chat" },
  { href: "/profile", label: "Profile", icon: "profile" },
];

function Icon({ name, active }: { name: string; active?: boolean }) {
  const stroke = active ? "#4f46e5" : "#475569";
  const common = { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: stroke, strokeWidth: 2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (name) {
    case "home":
      return <svg {...common}><path d="M3 9.5L12 3l9 6.5V21a2 2 0 0 1-2 2h-4v-7h-6v7H5a2 2 0 0 1-2-2V9.5z" /></svg>;
    case "search":
      return <svg {...common}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>;
    case "upload":
      return <svg {...common}><rect x="3" y="3" width="18" height="18" rx="3" /><path d="M12 8v8M8 12h8" /></svg>;
    case "chat":
      return <svg {...common}><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg>;
    case "profile":
      return <svg {...common}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>;
    case "logout":
      return <svg {...common}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="M16 17l5-5-5-5" /><path d="M21 12H9" /></svg>;
    default:
      return null;
  }
}

function Logo() {
  return (
    <Link href="/home" className="flex items-center gap-2 group">
      <div className="relative h-9 w-9 rounded-2xl bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 shadow-md shadow-indigo-500/20">
        <span className="absolute inset-0 flex items-center justify-center text-white font-extrabold text-sm tracking-wide">r</span>
      </div>
      <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-indigo-600 via-fuchsia-600 to-rose-500 bg-clip-text text-transparent">rifav</span>
    </Link>
  );
}

function GlobalSearch() {
  const router = useRouter();
  const [q, setQ] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`);
      }}
      className="hidden md:flex items-center w-full max-w-md bg-white border border-slate-200 rounded-2xl pl-4 pr-2 py-1.5 shadow-sm focus-within:ring-2 focus-within:ring-indigo-200 focus-within:border-indigo-300"
    >
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search rifav — people, posts, ideas"
        className="flex-1 bg-transparent px-3 py-1.5 outline-none text-sm placeholder:text-slate-400"
      />
      <kbd className="hidden lg:inline-block text-[10px] text-slate-500 bg-slate-100 border border-slate-200 rounded px-1.5 py-0.5">Enter</kbd>
    </form>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, loading, logout } = useAuth();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  // No auto-redirect: browse mode is allowed for everyone.
  // Login/Signup prompts are shown when the user tries to perform an action.

  if (!mounted) {
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="flex items-center gap-3 text-slate-500">
          <div className="h-3 w-3 rounded-full bg-indigo-500 animate-pulse" />
          <div className="h-3 w-3 rounded-full bg-fuchsia-500 animate-pulse [animation-delay:120ms]" />
          <div className="h-3 w-3 rounded-full bg-rose-500 animate-pulse [animation-delay:240ms]" />
          <span className="ml-2 text-sm font-medium">Loading rifav…</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-[#f7f7f8]">
      {/* Sidebar — desktop */}
      <aside className="hidden md:flex md:flex-col w-64 shrink-0 sticky top-0 h-screen border-r border-slate-200 bg-white/80 backdrop-blur">
        <div className="px-5 py-5"><Logo /></div>
        <nav className="flex-1 px-3 space-y-1">
          {NAV.map((n) => {
            const active = pathname === n.href || (n.href !== "/home" && pathname.startsWith(n.href));
            return (
              <Link
                key={n.href}
                href={n.href}
                className={cls(
                  "flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-medium transition",
                  active
                    ? "bg-indigo-50 text-indigo-700"
                    : "text-slate-700 hover:bg-slate-100",
                )}
              >
                <Icon name={n.icon} active={active} />
                <span>{n.label}</span>
                {n.label === "Upload" && (
                  <span className="ml-auto text-[10px] font-bold uppercase tracking-wider bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white rounded-full px-2 py-0.5">new</span>
                )}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-slate-200 space-y-2">
          {user ? (
            <>
              <Link
                href={`/u/${user.username}`}
                className="flex items-center gap-3 p-2 rounded-2xl hover:bg-slate-100"
              >
                <img src={user.avatarUrl} alt="" className="h-9 w-9 rounded-full ring-1 ring-slate-200" />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold truncate">{user.displayName}</div>
                  <div className="text-xs text-slate-500 truncate">@{user.username}</div>
                </div>
              </Link>
              <button
                onClick={async () => {
                  await logout();
                  router.refresh();
                }}
                className="w-full flex items-center gap-2 rounded-2xl px-3 py-2 text-sm text-slate-600 hover:bg-slate-100"
              >
                <Icon name="logout" />
                <span>Log out</span>
              </button>
            </>
          ) : (
            <>
              <div className="px-2 py-1.5 text-xs text-slate-500">
                You're browsing as a guest.
              </div>
              <Link
                href="/login"
                className="block text-center rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold px-3 py-2"
              >
                Log in
              </Link>
              <Link
                href="/signup"
                className="block text-center rounded-2xl border border-slate-200 hover:border-slate-300 text-sm font-semibold px-3 py-2"
              >
                Create account
              </Link>
            </>
          )}
        </div>
      </aside>

      {/* Main column */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white/85 backdrop-blur border-b border-slate-200">
          <div className="flex items-center gap-3 px-4 sm:px-6 py-3">
            <div className="md:hidden"><Logo /></div>
            <div className="flex-1 flex justify-center">
              <GlobalSearch />
            </div>
            <div className="hidden md:flex items-center gap-2">
              {user ? (
                <Link
                  href="/upload"
                  className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white text-sm font-semibold px-4 py-2 shadow-sm hover:opacity-95 active:scale-[.98] transition"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14" /></svg>
                  Upload
                </Link>
              ) : (
                <>
                  <Link
                    href="/login"
                    className="text-sm font-semibold text-slate-700 hover:text-slate-900 px-3 py-2"
                  >
                    Log in
                  </Link>
                  <Link
                    href="/signup"
                    className="inline-flex items-center gap-2 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold px-4 py-2"
                  >
                    Sign up
                  </Link>
                </>
              )}
            </div>
          </div>
        </header>

        <main className="flex-1 min-w-0">{children}</main>

        {/* Mobile bottom nav */}
        <nav className="md:hidden sticky bottom-0 z-20 bg-white/95 backdrop-blur border-t border-slate-200">
          <div className="grid grid-cols-5">
            {NAV.map((n) => {
              const active = pathname === n.href || (n.href !== "/home" && pathname.startsWith(n.href));
              return (
                <Link
                  key={n.href}
                  href={n.href}
                  className={cls(
                    "flex flex-col items-center justify-center py-2.5 text-[11px] font-medium",
                    active ? "text-indigo-600" : "text-slate-500",
                  )}
                >
                  <Icon name={n.icon} active={active} />
                  <span className="mt-0.5">{n.label}</span>
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
